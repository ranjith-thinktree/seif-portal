-- Quick Insert: Create 6 Test Centers
-- IMPORTANT: Replace 'YOUR_PARTNER_UUID_HERE' with your actual partner UUID
-- Get your partner UUID by running: SELECT id, name FROM partners;

-- First, get your partner ID:
SELECT id, name FROM partners LIMIT 10;

-- Then run this with your partner UUID:
INSERT INTO centers (
    id,
    center_id, 
    center_name, 
    city, 
    state, 
    country, 
    partner_id, 
    status, 
    approval_status, 
    created_at
) VALUES
(UUID(), 'C001', 'SEIF Skill Center - Pune', 'Pune', 'Maharashtra', 'India', 'YOUR_PARTNER_UUID_HERE', 'active', 'approved', NOW()),
(UUID(), 'C002', 'SEIF Training Hub - Mumbai', 'Mumbai', 'Maharashtra', 'India', 'YOUR_PARTNER_UUID_HERE', 'active', 'approved', NOW()),
(UUID(), 'C003', 'SEIF Vocational Institute - Bangalore', 'Bangalore', 'Karnataka', 'India', 'YOUR_PARTNER_UUID_HERE', 'active', 'approved', NOW()),
(UUID(), 'C004', 'SEIF Learning Center - Chennai', 'Chennai', 'Tamil Nadu', 'India', 'YOUR_PARTNER_UUID_HERE', 'active', 'approved', NOW()),
(UUID(), 'C005', 'SEIF Excellence Academy - Hyderabad', 'Hyderabad', 'Telangana', 'India', 'YOUR_PARTNER_UUID_HERE', 'active', 'approved', NOW()),
(UUID(), 'C006', 'SEIF Development Center - Delhi', 'Delhi', 'Delhi', 'India', 'YOUR_PARTNER_UUID_HERE', 'active', 'approved', NOW());

-- Verify centers were created:
SELECT center_id, center_name, city, state, status, approval_status 
FROM centers 
WHERE center_id IN ('C001', 'C002', 'C003', 'C004', 'C005', 'C006');
