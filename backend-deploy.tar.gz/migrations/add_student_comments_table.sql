-- Migration: Add student_comments table for Excel-like comments and notes
-- Purpose: Store cell-level comments and notes for uploaded students
-- Date: December 17, 2025

CREATE TABLE IF NOT EXISTS student_comments (
  id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
  student_id VARCHAR(36) NOT NULL,
  field_name VARCHAR(100) NOT NULL COMMENT 'Column/field name where comment is attached',
  type ENUM('comment', 'note') NOT NULL DEFAULT 'comment',
  content TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  INDEX idx_student_id (student_id),
  INDEX idx_student_field (student_id, field_name),
  INDEX idx_type (type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
COMMENT='Stores comments and notes for student data cells';
