-- =====================================================
-- SEIF Portal - Password Management Enhancement
-- Migration: Add Password Change and History Tracking
-- Date: December 15, 2025
-- =====================================================

-- Purpose:
-- 1. Add fields to track password changes and force password updates
-- 2. Create password history table to prevent password reuse
-- 3. Ensure security compliance for all user roles except ESSCI

-- =====================================================
-- STEP 1: Add Password Management Fields to Users Table
-- =====================================================

-- Add flag to force user to change password on next login
ALTER TABLE users 
ADD COLUMN must_change_password BOOLEAN DEFAULT FALSE 
COMMENT 'Force user to change password on next login';

-- Add timestamp for when password was last changed
ALTER TABLE users 
ADD COLUMN password_changed_at TIMESTAMP NULL 
COMMENT 'Timestamp of last password change';

-- Add flag to track if this is user's first login
ALTER TABLE users 
ADD COLUMN first_login BOOLEAN DEFAULT TRUE 
COMMENT 'TRUE if user has never logged in before';

-- =====================================================
-- STEP 2: Create Password History Table
-- =====================================================

CREATE TABLE IF NOT EXISTS password_history (
  id CHAR(36) PRIMARY KEY,
  user_id CHAR(36) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_user_created (user_id, created_at DESC),
  CONSTRAINT fk_password_history_user FOREIGN KEY (user_id) 
    REFERENCES users(id) 
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci
COMMENT 'Stores password history to prevent reuse of recent passwords';

-- =====================================================
-- STEP 3: Initialize Data for Existing Users
-- =====================================================

-- Set password_changed_at to created_at for existing users
-- This assumes their current password was set when account was created
UPDATE users 
SET password_changed_at = created_at 
WHERE password_changed_at IS NULL;

-- Mark all existing users as NOT first login if they have logged in before
UPDATE users 
SET first_login = FALSE 
WHERE last_login_at IS NOT NULL;

-- Keep first_login = TRUE for users who never logged in
-- (These will be forced to change password on first login)

-- =====================================================
-- STEP 4: Create Password History Entries for Existing Users
-- =====================================================

-- Insert current passwords into password_history for all active users
-- This ensures the current password is tracked and can't be reused
INSERT INTO password_history (id, user_id, password_hash, created_at)
SELECT 
  UUID() as id,
  id as user_id,
  password_hash,
  COALESCE(password_changed_at, created_at) as created_at
FROM users
WHERE status = 'active'
  AND password_hash IS NOT NULL;

-- =====================================================
-- STEP 5: Set must_change_password for Specific Cases
-- =====================================================

-- Force password change for users who never logged in
-- (Newly created partners, admins, etc.)
UPDATE users 
SET must_change_password = TRUE 
WHERE first_login = TRUE 
  AND role != 'ESSCI';

-- Note: ESSCI users are excluded because they request admin for password reset
-- They don't have access to self-service password change

-- =====================================================
-- STEP 6: Add Indexes for Performance
-- =====================================================

-- Index on must_change_password for quick filtering during login
CREATE INDEX idx_must_change_password ON users(must_change_password);

-- Index on first_login for reporting
CREATE INDEX idx_first_login ON users(first_login);

-- =====================================================
-- STEP 7: Verification Queries
-- =====================================================

-- Verify new columns were added
SELECT 
  TABLE_NAME,
  COLUMN_NAME,
  COLUMN_TYPE,
  COLUMN_DEFAULT,
  COLUMN_COMMENT
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'users'
  AND COLUMN_NAME IN ('must_change_password', 'password_changed_at', 'first_login');

-- Verify password_history table was created
SELECT 
  TABLE_NAME,
  ENGINE,
  TABLE_ROWS,
  TABLE_COMMENT
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'password_history';

-- Check users who must change password
SELECT 
  id,
  email,
  full_name,
  role,
  must_change_password,
  first_login,
  last_login_at,
  password_changed_at
FROM users
WHERE must_change_password = TRUE
ORDER BY role, email;

-- Check password history count per user
SELECT 
  u.email,
  u.full_name,
  u.role,
  COUNT(ph.id) as password_history_count,
  MAX(ph.created_at) as last_password_change
FROM users u
LEFT JOIN password_history ph ON u.id = ph.user_id
GROUP BY u.id, u.email, u.full_name, u.role
ORDER BY u.role, u.email;

-- =====================================================
-- STEP 8: Summary Statistics
-- =====================================================

SELECT 
  'Total Users' as metric,
  COUNT(*) as count
FROM users
WHERE status = 'active'

UNION ALL

SELECT 
  'Users Who Must Change Password',
  COUNT(*)
FROM users
WHERE must_change_password = TRUE

UNION ALL

SELECT 
  'First Time Login Users',
  COUNT(*)
FROM users
WHERE first_login = TRUE

UNION ALL

SELECT 
  'Users With Password History',
  COUNT(DISTINCT user_id)
FROM password_history

UNION ALL

SELECT 
  'Total Password History Records',
  COUNT(*)
FROM password_history;

-- =====================================================
-- ROLLBACK SCRIPT (If Needed)
-- =====================================================
-- UNCOMMENT BELOW LINES ONLY IF YOU NEED TO ROLLBACK THIS MIGRATION

/*
-- Drop indexes
DROP INDEX IF EXISTS idx_must_change_password ON users;
DROP INDEX IF EXISTS idx_first_login ON users;

-- Drop password_history table
DROP TABLE IF EXISTS password_history;

-- Remove columns from users table
ALTER TABLE users DROP COLUMN IF EXISTS must_change_password;
ALTER TABLE users DROP COLUMN IF EXISTS password_changed_at;
ALTER TABLE users DROP COLUMN IF EXISTS first_login;
*/

-- =====================================================
-- END OF MIGRATION
-- =====================================================

SELECT '✅ Password management migration completed successfully!' as status;
