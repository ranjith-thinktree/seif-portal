-- Migration: Add data_edit_logs table and version/parent_upload_id to data_uploads
-- Date: November 27, 2025
-- Purpose: Support partner data editing and resubmission with versioning

-- Add versioning columns to data_uploads table
ALTER TABLE `data_uploads`
  ADD COLUMN `version` int(11) DEFAULT 1 COMMENT 'Upload version number (1, 2, 3, etc.)' AFTER `upload_type`,
  ADD COLUMN `parent_upload_id` char(36) DEFAULT NULL COMMENT 'Original upload ID for versioned resubmissions' AFTER `version`,
  ADD KEY `data_uploads_index_parent` (`parent_upload_id`);

-- Create data_edit_logs table
CREATE TABLE `data_edit_logs` (
  `id` char(36) NOT NULL,
  `upload_id` char(36) NOT NULL COMMENT 'The resubmitted upload ID',
  `original_upload_id` char(36) NOT NULL COMMENT 'The original rejected upload ID',
  `student_id` char(36) NOT NULL COMMENT 'Student record that was edited',
  `field_name` varchar(100) NOT NULL COMMENT 'Field that was changed',
  `old_value` text DEFAULT NULL COMMENT 'Previous value',
  `new_value` text DEFAULT NULL COMMENT 'New value after edit',
  `edited_by` char(36) NOT NULL COMMENT 'User who made the edit (partner user)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Add primary key
ALTER TABLE `data_edit_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `data_edit_logs_index_1` (`upload_id`),
  ADD KEY `data_edit_logs_index_2` (`original_upload_id`),
  ADD KEY `data_edit_logs_index_3` (`student_id`),
  ADD KEY `data_edit_logs_index_4` (`edited_by`);

-- Add foreign key constraints
ALTER TABLE `data_edit_logs`
  ADD CONSTRAINT `data_edit_logs_ibfk_1` FOREIGN KEY (`upload_id`) REFERENCES `data_uploads` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `data_edit_logs_ibfk_2` FOREIGN KEY (`original_upload_id`) REFERENCES `data_uploads` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `data_edit_logs_ibfk_3` FOREIGN KEY (`student_id`) REFERENCES `uploaded_students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `data_edit_logs_ibfk_4` FOREIGN KEY (`edited_by`) REFERENCES `users` (`id`);

-- Add foreign key for parent_upload_id in data_uploads
ALTER TABLE `data_uploads`
  ADD CONSTRAINT `data_uploads_ibfk_parent` FOREIGN KEY (`parent_upload_id`) REFERENCES `data_uploads` (`id`) ON DELETE SET NULL;
