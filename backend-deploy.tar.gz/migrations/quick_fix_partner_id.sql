-- Quick fix for existing partner_id column
-- Run this if you already ran the migration and need to fix existing data

-- Reset row number variable
SET @row_number = 0;

-- Update all partners with new readable IDs
UPDATE partners 
SET partner_id = CONCAT('PART-', LPAD((@row_number:=@row_number + 1), 4, '0'))
ORDER BY created_at;

-- Verify the results
SELECT id, partner_id, name, created_at 
FROM partners 
ORDER BY created_at 
LIMIT 10;
