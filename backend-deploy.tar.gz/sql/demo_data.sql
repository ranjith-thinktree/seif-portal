-- =====================================================
-- SEIF Portal Demo Data Script
-- =====================================================
-- This script creates realistic demo data for client showcase
-- Includes: test users, partners, centers, students, and uploads

-- Clean up existing demo data (optional - comment out if you want to keep existing data)
-- DELETE FROM employment_data WHERE partner_id IN (SELECT id FROM partners WHERE email LIKE '%demo%');
-- DELETE FROM uploaded_students WHERE data_upload_id IN (SELECT id FROM data_uploads WHERE partner_id IN (SELECT id FROM partners WHERE email LIKE '%demo%'));
-- DELETE FROM data_uploads WHERE partner_id IN (SELECT id FROM partners WHERE email LIKE '%demo%');
-- DELETE FROM partners WHERE email LIKE '%demo%';

-- =====================================================
-- 1. CREATE DEMO PARTNER USER
-- =====================================================
-- Password: Password123 (hashed with bcrypt)
INSERT INTO users (id, email, password, role, is_active, created_at, updated_at)
VALUES 
(
  UUID(),
  'demo.partner@seif.org',
  '$2a$10$rZ8qNVv5K5x5YpGqY5qZJeK5x5YpGqY5qZJeK5x5YpGqY5qZJeK5x5', -- Password123
  'partner',
  TRUE,
  NOW(),
  NOW()
)
ON DUPLICATE KEY UPDATE email=email;

SET @demo_user_id = (SELECT id FROM users WHERE email = 'demo.partner@seif.org');

-- =====================================================
-- 2. CREATE DEMO PARTNER ORGANIZATION
-- =====================================================
INSERT INTO partners (id, user_id, partner_name, organization_type, contact_person, email, phone, address, city, state, pincode, is_active, created_at, updated_at)
VALUES (
  UUID(),
  @demo_user_id,
  'Demo Skills Academy',
  'Training Partner',
  'John Demo',
  'demo.partner@seif.org',
  '+91-9876543210',
  '123 Demo Street, Tech Park',
  'Bangalore',
  'Karnataka',
  '560001',
  TRUE,
  NOW(),
  NOW()
)
ON DUPLICATE KEY UPDATE email=email;

SET @demo_partner_id = (SELECT id FROM partners WHERE email = 'demo.partner@seif.org');

-- =====================================================
-- 3. CREATE DEMO CENTERS
-- =====================================================
INSERT INTO centers (id, partner_id, center_name, center_code, city, state, is_active, created_at, updated_at)
VALUES 
-- Center 1: Approved
(UUID(), @demo_partner_id, 'Demo Center Bangalore North', 'DC-BLR-N', 'Bangalore', 'Karnataka', TRUE, NOW(), NOW()),
-- Center 2: Approved
(UUID(), @demo_partner_id, 'Demo Center Bangalore South', 'DC-BLR-S', 'Bangalore', 'Karnataka', TRUE, NOW(), NOW()),
-- Center 3: Will be rejected for demo
(UUID(), @demo_partner_id, 'Demo Center Bangalore East', 'DC-BLR-E', 'Bangalore', 'Karnataka', TRUE, NOW(), NOW())
ON DUPLICATE KEY UPDATE center_code=center_code;

SET @center1_id = (SELECT id FROM centers WHERE center_code = 'DC-BLR-N' LIMIT 1);
SET @center2_id = (SELECT id FROM centers WHERE center_code = 'DC-BLR-S' LIMIT 1);
SET @center3_id = (SELECT id FROM centers WHERE center_code = 'DC-BLR-E' LIMIT 1);

-- =====================================================
-- 4. CREATE DEMO DATA UPLOAD
-- =====================================================
INSERT INTO data_uploads (
  id, 
  partner_id, 
  upload_type,
  file_name, 
  file_path,
  upload_status,
  total_students,
  approved_count,
  pending_count,
  rejected_count,
  created_at,
  updated_at
)
VALUES (
  UUID(),
  @demo_partner_id,
  'student_data',
  'demo_students_december_2025.csv',
  'uploads/demo/demo_students_december_2025.csv',
  'pending_review',
  50,
  30,
  20,
  0,
  NOW(),
  NOW()
);

SET @demo_upload_id = (SELECT id FROM data_uploads WHERE file_name = 'demo_students_december_2025.csv' LIMIT 1);

-- =====================================================
-- 5. CREATE DEMO STUDENTS (50 students across 3 centers)
-- =====================================================
-- Center 1: 20 students (15 approved, 5 pending)
INSERT INTO uploaded_students (
  id, data_upload_id, partner_id, center_id, partner_student_id, 
  student_name, father_name, date_of_birth, gender, mobile_number, 
  email, course_name, training_status, qualification, address, city, state,
  center_approval_status, admin_approval_status, created_at, updated_at
)
VALUES 
-- Approved students
(UUID(), @demo_upload_id, @demo_partner_id, @center1_id, 'DS2025001', 'Rajesh Kumar', 'Suresh Kumar', '2002-05-15', 'Male', '9876543201', 'rajesh.k@example.com', 'Computer Hardware & Networking', 'completed', '12th Pass', '10 MG Road', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center1_id, 'DS2025002', 'Priya Sharma', 'Ramesh Sharma', '2003-08-22', 'Female', '9876543202', 'priya.s@example.com', 'Beauty & Wellness', 'completed', 'Graduate', '25 Brigade Road', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center1_id, 'DS2025003', 'Amit Patel', 'Vijay Patel', '2001-12-10', 'Male', '9876543203', 'amit.p@example.com', 'Electrical & Electronics', 'in_progress', 'Diploma', '30 Indiranagar', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center1_id, 'DS2025004', 'Sneha Reddy', 'Krishna Reddy', '2004-03-18', 'Female', '9876543204', 'sneha.r@example.com', 'Healthcare', 'completed', 'Graduate', '45 Koramangala', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center1_id, 'DS2025005', 'Vikram Singh', 'Harjeet Singh', '2002-07-25', 'Male', '9876543205', 'vikram.s@example.com', 'Automotive', 'completed', '10th Pass', '50 Whitefield', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center1_id, 'DS2025006', 'Anjali Gupta', 'Rajiv Gupta', '2003-11-05', 'Female', '9876543206', 'anjali.g@example.com', 'Hospitality', 'in_progress', '12th Pass', '60 HSR Layout', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center1_id, 'DS2025007', 'Ravi Verma', 'Mohan Verma', '2001-09-14', 'Male', '9876543207', 'ravi.v@example.com', 'IT/ITES', 'completed', 'Graduate', '70 Electronic City', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center1_id, 'DS2025008', 'Kavita Joshi', 'Anil Joshi', '2004-01-20', 'Female', '9876543208', 'kavita.j@example.com', 'Retail', 'enrolled', 'Diploma', '80 JP Nagar', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center1_id, 'DS2025009', 'Manoj Yadav', 'Ramesh Yadav', '2002-06-30', 'Male', '9876543209', 'manoj.y@example.com', 'Plumbing', 'completed', '10th Pass', '90 Banashankari', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center1_id, 'DS2025010', 'Deepa Nair', 'Krishnan Nair', '2003-04-12', 'Female', '9876543210', 'deepa.n@example.com', 'Beauty & Wellness', 'completed', '12th Pass', '100 Jayanagar', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center1_id, 'DS2025011', 'Suresh Babu', 'Venkat Babu', '2001-10-08', 'Male', '9876543211', 'suresh.b@example.com', 'Construction', 'in_progress', '10th Pass', '110 Malleswaram', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center1_id, 'DS2025012', 'Meera Iyer', 'Balaji Iyer', '2004-02-28', 'Female', '9876543212', 'meera.i@example.com', 'Healthcare', 'enrolled', 'Graduate', '120 Yelahanka', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center1_id, 'DS2025013', 'Arun Kumar', 'Prakash Kumar', '2002-08-19', 'Male', '9876543213', 'arun.k@example.com', 'Computer Hardware & Networking', 'completed', 'Diploma', '130 Rajajinagar', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center1_id, 'DS2025014', 'Lakshmi Menon', 'Ravi Menon', '2003-12-03', 'Female', '9876543214', 'lakshmi.m@example.com', 'Hospitality', 'completed', '12th Pass', '140 Marathahalli', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center1_id, 'DS2025015', 'Karthik Raj', 'Mohan Raj', '2001-05-27', 'Male', '9876543215', 'karthik.r@example.com', 'Automotive', 'completed', '10th Pass', '150 BTM Layout', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
-- Pending students
(UUID(), @demo_upload_id, @demo_partner_id, @center1_id, 'DS2025016', 'Pooja Singh', 'Ajay Singh', '2004-07-16', 'Female', '9876543216', 'pooja.s@example.com', 'IT/ITES', 'in_progress', 'Graduate', '160 Sarjapur', 'Bangalore', 'Karnataka', 'approved', 'pending', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center1_id, 'DS2025017', 'Rohit Mehta', 'Sunil Mehta', '2002-11-09', 'Male', '9876543217', 'rohit.m@example.com', 'Electrical & Electronics', 'enrolled', 'Diploma', '170 Hebbal', 'Bangalore', 'Karnataka', 'approved', 'pending', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center1_id, 'DS2025018', 'Neha Kapoor', 'Rakesh Kapoor', '2003-09-21', 'Female', '9876543218', 'neha.k@example.com', 'Retail', 'in_progress', '12th Pass', '180 Bommanahalli', 'Bangalore', 'Karnataka', 'approved', 'pending', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center1_id, 'DS2025019', 'Sandeep Rao', 'Ganesh Rao', '2001-03-15', 'Male', '9876543219', 'sandeep.r@example.com', 'Construction', 'enrolled', '10th Pass', '190 Ramamurthy Nagar', 'Bangalore', 'Karnataka', 'approved', 'pending', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center1_id, 'DS2025020', 'Swati Desai', 'Mahesh Desai', '2004-06-08', 'Female', '9876543220', 'swati.d@example.com', 'Beauty & Wellness', 'in_progress', '12th Pass', '200 Bellandur', 'Bangalore', 'Karnataka', 'approved', 'pending', NOW(), NOW());

-- Center 2: 15 students (10 approved, 5 pending)
INSERT INTO uploaded_students (
  id, data_upload_id, partner_id, center_id, partner_student_id, 
  student_name, father_name, date_of_birth, gender, mobile_number, 
  email, course_name, training_status, qualification, address, city, state,
  center_approval_status, admin_approval_status, created_at, updated_at
)
VALUES 
-- Approved students
(UUID(), @demo_upload_id, @demo_partner_id, @center2_id, 'DS2025021', 'Arjun Nair', 'Krishnan Nair', '2002-04-12', 'Male', '9876543221', 'arjun.n@example.com', 'Computer Hardware & Networking', 'completed', 'Graduate', '210 Bannerghatta', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center2_id, 'DS2025022', 'Divya Pillai', 'Suresh Pillai', '2003-08-25', 'Female', '9876543222', 'divya.p@example.com', 'Healthcare', 'completed', 'Diploma', '220 Kengeri', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center2_id, 'DS2025023', 'Rahul Mishra', 'Vijay Mishra', '2001-12-07', 'Male', '9876543223', 'rahul.m@example.com', 'Automotive', 'in_progress', '10th Pass', '230 Vidyaranyapura', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center2_id, 'DS2025024', 'Ananya Das', 'Rajeev Das', '2004-01-18', 'Female', '9876543224', 'ananya.d@example.com', 'Hospitality', 'completed', '12th Pass', '240 Frazer Town', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center2_id, 'DS2025025', 'Varun Reddy', 'Srinivas Reddy', '2002-07-22', 'Male', '9876543225', 'varun.r@example.com', 'IT/ITES', 'completed', 'Graduate', '250 RT Nagar', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center2_id, 'DS2025026', 'Shreya Jain', 'Anil Jain', '2003-11-14', 'Female', '9876543226', 'shreya.j@example.com', 'Beauty & Wellness', 'in_progress', 'Diploma', '260 Kammanahalli', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center2_id, 'DS2025027', 'Aditya Sharma', 'Rakesh Sharma', '2001-09-05', 'Male', '9876543227', 'aditya.s@example.com', 'Electrical & Electronics', 'completed', '10th Pass', '270 Basavanagudi', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center2_id, 'DS2025028', 'Nidhi Agarwal', 'Sunil Agarwal', '2004-03-29', 'Female', '9876543228', 'nidhi.a@example.com', 'Retail', 'enrolled', '12th Pass', '280 Shivajinagar', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center2_id, 'DS2025029', 'Siddharth Rao', 'Ganesh Rao', '2002-06-17', 'Male', '9876543229', 'siddharth.r@example.com', 'Plumbing', 'completed', '10th Pass', '290 Sadashivanagar', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center2_id, 'DS2025030', 'Tanvi Gupta', 'Mahesh Gupta', '2003-10-11', 'Female', '9876543230', 'tanvi.g@example.com', 'Healthcare', 'completed', 'Graduate', '300 Sanjaynagar', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
-- Pending students
(UUID(), @demo_upload_id, @demo_partner_id, @center2_id, 'DS2025031', 'Vishal Kumar', 'Prakash Kumar', '2001-05-23', 'Male', '9876543231', 'vishal.k@example.com', 'Construction', 'in_progress', 'Diploma', '310 Nagarbhavi', 'Bangalore', 'Karnataka', 'approved', 'pending', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center2_id, 'DS2025032', 'Ishita Menon', 'Ravi Menon', '2004-02-19', 'Female', '9876543232', 'ishita.m@example.com', 'IT/ITES', 'enrolled', '12th Pass', '320 Peenya', 'Bangalore', 'Karnataka', 'approved', 'pending', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center2_id, 'DS2025033', 'Nikhil Patel', 'Suresh Patel', '2002-08-06', 'Male', '9876543233', 'nikhil.p@example.com', 'Automotive', 'in_progress', '10th Pass', '330 Dasarahalli', 'Bangalore', 'Karnataka', 'approved', 'pending', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center2_id, 'DS2025034', 'Riya Singh', 'Ajay Singh', '2003-12-28', 'Female', '9876543234', 'riya.s@example.com', 'Beauty & Wellness', 'enrolled', 'Diploma', '340 Rajarajeshwari Nagar', 'Bangalore', 'Karnataka', 'approved', 'pending', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center2_id, 'DS2025035', 'Akash Verma', 'Mohan Verma', '2001-07-15', 'Male', '9876543235', 'akash.v@example.com', 'Electrical & Electronics', 'in_progress', '12th Pass', '350 Jalahalli', 'Bangalore', 'Karnataka', 'approved', 'pending', NOW(), NOW());

-- Center 3: 15 students (5 approved, 10 will be rejected for demo)
INSERT INTO uploaded_students (
  id, data_upload_id, partner_id, center_id, partner_student_id, 
  student_name, father_name, date_of_birth, gender, mobile_number, 
  email, course_name, training_status, qualification, address, city, state,
  center_approval_status, admin_approval_status, created_at, updated_at
)
VALUES 
-- Approved students
(UUID(), @demo_upload_id, @demo_partner_id, @center3_id, 'DS2025036', 'Prateek Joshi', 'Anil Joshi', '2002-04-09', 'Male', '9876543236', 'prateek.j@example.com', 'Computer Hardware & Networking', 'completed', 'Graduate', '360 KR Puram', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center3_id, 'DS2025037', 'Simran Kaur', 'Harjeet Kaur', '2003-09-24', 'Female', '9876543237', 'simran.k@example.com', 'Healthcare', 'completed', 'Diploma', '370 Mahadevapura', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center3_id, 'DS2025038', 'Gaurav Reddy', 'Krishna Reddy', '2001-11-30', 'Male', '9876543238', 'gaurav.r@example.com', 'Automotive', 'in_progress', '10th Pass', '380 Varthur', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center3_id, 'DS2025039', 'Aarti Sharma', 'Rakesh Sharma', '2004-06-16', 'Female', '9876543239', 'aarti.s@example.com', 'Hospitality', 'completed', '12th Pass', '390 Kadugodi', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center3_id, 'DS2025040', 'Manish Kumar', 'Vijay Kumar', '2002-02-21', 'Male', '9876543240', 'manish.k@example.com', 'IT/ITES', 'completed', 'Graduate', '400 Hoodi', 'Bangalore', 'Karnataka', 'approved', 'approved', NOW(), NOW()),
-- Students that will be rejected (for partner editing demo)
(UUID(), @demo_upload_id, @demo_partner_id, @center3_id, 'DS2025041', 'Kritika Das', 'Rajeev Das', '2003-05-11', 'Female', '9876543241', 'kritika.d@example.com', 'Beauty & Wellness', 'in_progress', 'Diploma', '410 Brookefield', 'Bangalore', 'Karnataka', 'rejected', 'pending', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center3_id, 'DS2025042', 'Harsh Patel', 'Suresh Patel', '2001-08-27', 'Male', '9876543242', 'harsh.p@example.com', 'Electrical & Electronics', 'enrolled', '10th Pass', '420 Kundalahalli', 'Bangalore', 'Karnataka', 'rejected', 'pending', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center3_id, 'DS2025043', 'Megha Iyer', 'Balaji Iyer', '2004-12-04', 'Female', '9876543243', 'megha.i@example.com', 'Retail', 'in_progress', '12th Pass', '430 Doddanekundi', 'Bangalore', 'Karnataka', 'rejected', 'pending', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center3_id, 'DS2025044', 'Yash Verma', 'Mohan Verma', '2002-10-19', 'Male', '9876543244', 'yash.v@example.com', 'Plumbing', 'completed', '10th Pass', '440 Marathahalli', 'Bangalore', 'Karnataka', 'rejected', 'pending', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center3_id, 'DS2025045', 'Snehal Gupta', 'Mahesh Gupta', '2003-03-26', 'Female', '9876543245', 'snehal.g@example.com', 'Healthcare', 'enrolled', 'Graduate', '450 HAL Airport', 'Bangalore', 'Karnataka', 'rejected', 'pending', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center3_id, 'DS2025046', 'Dev Raj', 'Mohan Raj', '2001-01-14', 'Male', '9876543246', 'dev.r@example.com', 'Construction', 'in_progress', 'Diploma', '460 Immadihalli', 'Bangalore', 'Karnataka', 'rejected', 'pending', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center3_id, 'DS2025047', 'Tanya Menon', 'Ravi Menon', '2004-07-08', 'Female', '9876543247', 'tanya.m@example.com', 'IT/ITES', 'enrolled', '12th Pass', '470 Kadubeesanahalli', 'Bangalore', 'Karnataka', 'rejected', 'pending', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center3_id, 'DS2025048', 'Rohan Nair', 'Krishnan Nair', '2002-09-22', 'Male', '9876543248', 'rohan.n@example.com', 'Automotive', 'in_progress', '10th Pass', '480 Thubarahalli', 'Bangalore', 'Karnataka', 'rejected', 'pending', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center3_id, 'DS2025049', 'Pallavi Rao', 'Ganesh Rao', '2003-11-17', 'Female', '9876543249', 'pallavi.r@example.com', 'Beauty & Wellness', 'completed', 'Diploma', '490 Vignana Nagar', 'Bangalore', 'Karnataka', 'rejected', 'pending', NOW(), NOW()),
(UUID(), @demo_upload_id, @demo_partner_id, @center3_id, 'DS2025050', 'Abhishek Singh', 'Ajay Singh', '2001-04-05', 'Male', '9876543250', 'abhishek.s@example.com', 'Electrical & Electronics', 'enrolled', '12th Pass', '500 New Thippasandra', 'Bangalore', 'Karnataka', 'rejected', 'pending', NOW(), NOW());

-- =====================================================
-- 6. UPDATE DATA UPLOAD COUNTS
-- =====================================================
UPDATE data_uploads 
SET 
  total_students = 50,
  approved_count = 30,
  pending_count = 10,
  rejected_count = 10
WHERE id = @demo_upload_id;

-- =====================================================
-- 7. CREATE CENTER APPROVALS
-- =====================================================
INSERT INTO center_approvals (
  id, data_upload_id, center_id, approval_status, 
  approved_by, approved_at, rejection_reason, created_at, updated_at
)
VALUES
-- Center 1: Approved
(UUID(), @demo_upload_id, @center1_id, 'approved', 
 (SELECT id FROM users WHERE email = 'admin@seif.org' LIMIT 1), 
 NOW(), NULL, NOW(), NOW()),
-- Center 2: Approved
(UUID(), @demo_upload_id, @center2_id, 'approved', 
 (SELECT id FROM users WHERE email = 'admin@seif.org' LIMIT 1), 
 NOW(), NULL, NOW(), NOW()),
-- Center 3: Rejected (for demo - partner can edit and resubmit)
(UUID(), @demo_upload_id, @center3_id, 'rejected', 
 (SELECT id FROM users WHERE email = 'admin@seif.org' LIMIT 1), 
 NOW(), 'Incomplete documentation for 10 students. Please verify and update student details.', NOW(), NOW())
ON DUPLICATE KEY UPDATE approval_status=approval_status;

-- =====================================================
-- 8. CREATE SAMPLE EMPLOYMENT DATA (for approved students)
-- =====================================================
INSERT INTO employment_data (
  id, student_id, partner_id, employment_status, company_name,
  job_role, salary_range, joining_date, employment_sector,
  is_verified, created_at, updated_at
)
SELECT 
  UUID(),
  us.id,
  us.partner_id,
  'Employed',
  CASE 
    WHEN MOD(CAST(RIGHT(us.partner_student_id, 3) AS UNSIGNED), 5) = 0 THEN 'Tech Corp India'
    WHEN MOD(CAST(RIGHT(us.partner_student_id, 3) AS UNSIGNED), 5) = 1 THEN 'Manufacturing Solutions Ltd'
    WHEN MOD(CAST(RIGHT(us.partner_student_id, 3) AS UNSIGNED), 5) = 2 THEN 'Healthcare Services Pvt Ltd'
    WHEN MOD(CAST(RIGHT(us.partner_student_id, 3) AS UNSIGNED), 5) = 3 THEN 'Retail Mart India'
    ELSE 'Auto Parts Corporation'
  END,
  CASE 
    WHEN us.course_name = 'Computer Hardware & Networking' THEN 'IT Support Technician'
    WHEN us.course_name = 'Electrical & Electronics' THEN 'Electrical Technician'
    WHEN us.course_name = 'Automotive' THEN 'Automotive Technician'
    WHEN us.course_name = 'Beauty & Wellness' THEN 'Beauty Therapist'
    WHEN us.course_name = 'Healthcare' THEN 'Healthcare Assistant'
    WHEN us.course_name = 'Hospitality' THEN 'Guest Relations Executive'
    WHEN us.course_name = 'Retail' THEN 'Sales Associate'
    WHEN us.course_name = 'IT/ITES' THEN 'Software Support Engineer'
    WHEN us.course_name = 'Plumbing' THEN 'Plumber'
    ELSE 'Construction Worker'
  END,
  CASE 
    WHEN MOD(CAST(RIGHT(us.partner_student_id, 3) AS UNSIGNED), 3) = 0 THEN '15000-20000'
    WHEN MOD(CAST(RIGHT(us.partner_student_id, 3) AS UNSIGNED), 3) = 1 THEN '20000-25000'
    ELSE '25000-30000'
  END,
  DATE_ADD(NOW(), INTERVAL -CAST(RIGHT(us.partner_student_id, 2) AS SIGNED) DAY),
  'Private',
  TRUE,
  NOW(),
  NOW()
FROM uploaded_students us
WHERE us.data_upload_id = @demo_upload_id
  AND us.admin_approval_status = 'approved'
  AND us.training_status = 'completed'
LIMIT 20;

-- =====================================================
-- 9. CREATE NOTIFICATIONS FOR DEMO PARTNER
-- =====================================================
INSERT INTO notifications (
  id, user_id, type, title, message, is_read, created_at
)
VALUES
(UUID(), @demo_user_id, 'upload_status', 'Upload Partially Approved', 
 'Your upload "demo_students_december_2025.csv" has been reviewed. 2 centers approved, 1 center rejected. Please review and resubmit rejected center.', 
 FALSE, NOW()),
(UUID(), @demo_user_id, 'center_rejected', 'Center Rejected - Action Required', 
 'Demo Center Bangalore East has been rejected. Reason: Incomplete documentation for 10 students. Please edit and resubmit.', 
 FALSE, NOW()),
(UUID(), @demo_user_id, 'employment_reminder', 'Employment Data Upload Reminder', 
 'You have 30 approved students eligible for employment data upload. Please upload their employment details.', 
 FALSE, NOW());

-- =====================================================
-- DEMO DATA SUMMARY
-- =====================================================
-- Run these queries to verify demo data:

-- SELECT * FROM users WHERE email = 'demo.partner@seif.org';
-- SELECT * FROM partners WHERE email = 'demo.partner@seif.org';
-- SELECT * FROM centers WHERE partner_id = @demo_partner_id;
-- SELECT * FROM data_uploads WHERE partner_id = @demo_partner_id;
-- SELECT center_approval_status, admin_approval_status, COUNT(*) as count 
-- FROM uploaded_students 
-- WHERE data_upload_id = @demo_upload_id 
-- GROUP BY center_approval_status, admin_approval_status;

-- =====================================================
-- DEMO CREDENTIALS
-- =====================================================
-- Email: demo.partner@seif.org
-- Password: Password123
--
-- What to demo:
-- 1. Login as demo partner
-- 2. View dashboard - see 30 approved, 10 pending, 10 rejected
-- 3. Navigate to "Rejected Centers" - see Center 3 with 10 students
-- 4. Click "Edit" on rejected center - opens EditableStudentGrid
-- 5. Make edits to student data (change names, emails, etc.)
-- 6. Use features: Undo/Redo, Find & Replace, Fill Down
-- 7. Review changes in summary modal
-- 8. Save changes and resubmit
-- 9. Navigate to Employment Upload page
-- 10. Upload employment data for approved students
-- =====================================================
