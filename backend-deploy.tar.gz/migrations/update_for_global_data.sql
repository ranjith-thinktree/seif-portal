-- =====================================================
-- UPDATE MIGRATION FOR GLOBAL LOCATION DATA
-- =====================================================
-- This migration updates the existing tables to support
-- global countries, states, and cities data
-- =====================================================

-- Update countries table structure to support more data
ALTER TABLE `countries`
ADD COLUMN `iso3` VARCHAR(3) DEFAULT NULL COMMENT 'ISO 3166-1 alpha-3 code' AFTER `code`,
ADD COLUMN `phone_code` VARCHAR(10) DEFAULT NULL COMMENT 'International dialing code',
ADD COLUMN `currency` VARCHAR(10) DEFAULT NULL COMMENT 'Currency code',
ADD INDEX `idx_iso3` (`iso3`);

-- Update cities table to support coordinates
ALTER TABLE `cities`
ADD COLUMN `latitude` VARCHAR(20) DEFAULT NULL COMMENT 'City latitude',
ADD COLUMN `longitude` VARCHAR(20) DEFAULT NULL COMMENT 'City longitude',
ADD INDEX `idx_coordinates` (`latitude`, `longitude`);

-- Update partners table to store numeric IDs for better performance
ALTER TABLE `partners`
ADD COLUMN `country_ref_id` INT DEFAULT NULL COMMENT 'Reference to countries.id' AFTER `country`,
ADD COLUMN `state_ref_id` INT DEFAULT NULL COMMENT 'Reference to states.id' AFTER `state`,
ADD COLUMN `city_ref_id` INT DEFAULT NULL COMMENT 'Reference to cities.id' AFTER `city`,
ADD INDEX `idx_country_ref` (`country_ref_id`),
ADD INDEX `idx_state_ref` (`state_ref_id`),
ADD INDEX `idx_city_ref` (`city_ref_id`);

-- Add foreign keys for data integrity (optional - can be skipped for performance)
-- ALTER TABLE `partners`
-- ADD CONSTRAINT `fk_partner_country` FOREIGN KEY (`country_ref_id`) REFERENCES `countries`(`id`) ON DELETE SET NULL,
-- ADD CONSTRAINT `fk_partner_state` FOREIGN KEY (`state_ref_id`) REFERENCES `states`(`id`) ON DELETE SET NULL,
-- ADD CONSTRAINT `fk_partner_city` FOREIGN KEY (`city_ref_id`) REFERENCES `cities`(`id`) ON DELETE SET NULL;

-- =====================================================
-- IMPORTANT: After running this migration, run:
-- node migrations/generate_global_data.js
-- Then import the generated SQL file
-- =====================================================
