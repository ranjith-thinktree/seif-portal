-- ==================================================
-- FIX PARTNER_ID COLUMN - Skip if already exists
-- ==================================================
-- Based on db_7.sql structure
-- Run this in your seif database

-- Step 1: Update existing partner with readable ID (column already exists)
UPDATE `partners` 
SET `partner_id` = 'PART-0001'
WHERE `id` = 'b0000000-0000-0000-0000-000000000001';

-- Step 2: If there are more partners, update them sequentially
SET @row_number = 0;
UPDATE `partners` 
SET `partner_id` = CONCAT('PART-', LPAD((@row_number:=@row_number + 1), 4, '0'))
WHERE `partner_id` IS NULL OR `partner_id` = '' OR `partner_id` LIKE 'b0000000-%'
ORDER BY `created_at`;

-- Step 3: Drop and recreate trigger for auto-generation
DROP TRIGGER IF EXISTS `before_partner_insert`;

DELIMITER $$

CREATE TRIGGER `before_partner_insert`
BEFORE INSERT ON `partners`
FOR EACH ROW
BEGIN
    DECLARE next_num INT;
    
    IF NEW.partner_id IS NULL OR NEW.partner_id = '' THEN
        -- Get the next number by finding the max existing number
        SELECT COALESCE(MAX(CAST(SUBSTRING(partner_id, 6) AS UNSIGNED)), 0) + 1 
        INTO next_num
        FROM partners 
        WHERE partner_id LIKE 'PART-%';
        
        SET NEW.partner_id = CONCAT('PART-', LPAD(next_num, 4, '0'));
    END IF;
END$$

DELIMITER ;

-- Verification: Check the result
SELECT id, partner_id, name, organization_type, city, state, created_at 
FROM partners 
ORDER BY created_at;

-- Expected output:
-- id: b0000000-0000-0000-0000-000000000001
-- partner_id: PART-0001
-- name: Don Bosco Tech Society
