-- =====================================================
-- Add Missing Partner Fields
-- Date: December 8, 2025
-- =====================================================
-- This migration adds the partner onboarding fields that
-- were not yet added to the database
-- =====================================================

USE seif;

-- Check if columns already exist before adding
SET @dbname = DATABASE();
SET @tablename = "partners";

-- Add region column if not exists
SET @column_check = (SELECT COUNT(*) 
                     FROM INFORMATION_SCHEMA.COLUMNS 
                     WHERE TABLE_SCHEMA = @dbname 
                     AND TABLE_NAME = @tablename 
                     AND COLUMN_NAME = 'region');

SET @query = IF(@column_check = 0,
    'ALTER TABLE `partners` ADD COLUMN `region` VARCHAR(50) DEFAULT NULL COMMENT ''N, S, E, W, UT (Union Territory)''',
    'SELECT ''Column region already exists'' AS Info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add contact_person_2_name if not exists
SET @column_check = (SELECT COUNT(*) 
                     FROM INFORMATION_SCHEMA.COLUMNS 
                     WHERE TABLE_SCHEMA = @dbname 
                     AND TABLE_NAME = @tablename 
                     AND COLUMN_NAME = 'contact_person_2_name');

SET @query = IF(@column_check = 0,
    'ALTER TABLE `partners` ADD COLUMN `contact_person_2_name` VARCHAR(255) DEFAULT NULL',
    'SELECT ''Column contact_person_2_name already exists'' AS Info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add contact_person_2_mobile if not exists
SET @column_check = (SELECT COUNT(*) 
                     FROM INFORMATION_SCHEMA.COLUMNS 
                     WHERE TABLE_SCHEMA = @dbname 
                     AND TABLE_NAME = @tablename 
                     AND COLUMN_NAME = 'contact_person_2_mobile');

SET @query = IF(@column_check = 0,
    'ALTER TABLE `partners` ADD COLUMN `contact_person_2_mobile` VARCHAR(20) DEFAULT NULL',
    'SELECT ''Column contact_person_2_mobile already exists'' AS Info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add date_of_incorporation if not exists
SET @column_check = (SELECT COUNT(*) 
                     FROM INFORMATION_SCHEMA.COLUMNS 
                     WHERE TABLE_SCHEMA = @dbname 
                     AND TABLE_NAME = @tablename 
                     AND COLUMN_NAME = 'date_of_incorporation');

SET @query = IF(@column_check = 0,
    'ALTER TABLE `partners` ADD COLUMN `date_of_incorporation` DATE DEFAULT NULL',
    'SELECT ''Column date_of_incorporation already exists'' AS Info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add legal_status if not exists
SET @column_check = (SELECT COUNT(*) 
                     FROM INFORMATION_SCHEMA.COLUMNS 
                     WHERE TABLE_SCHEMA = @dbname 
                     AND TABLE_NAME = @tablename 
                     AND COLUMN_NAME = 'legal_status');

SET @query = IF(@column_check = 0,
    'ALTER TABLE `partners` ADD COLUMN `legal_status` TEXT DEFAULT NULL COMMENT ''ACT under which it is registered''',
    'SELECT ''Column legal_status already exists'' AS Info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add registered_as if not exists
SET @column_check = (SELECT COUNT(*) 
                     FROM INFORMATION_SCHEMA.COLUMNS 
                     WHERE TABLE_SCHEMA = @dbname 
                     AND TABLE_NAME = @tablename 
                     AND COLUMN_NAME = 'registered_as');

SET @query = IF(@column_check = 0,
    'ALTER TABLE `partners` ADD COLUMN `registered_as` VARCHAR(100) DEFAULT NULL COMMENT ''Trust, Foundation, Section 25 Company''',
    'SELECT ''Column registered_as already exists'' AS Info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add fcra_registration_number if not exists
SET @column_check = (SELECT COUNT(*) 
                     FROM INFORMATION_SCHEMA.COLUMNS 
                     WHERE TABLE_SCHEMA = @dbname 
                     AND TABLE_NAME = @tablename 
                     AND COLUMN_NAME = 'fcra_registration_number');

SET @query = IF(@column_check = 0,
    'ALTER TABLE `partners` ADD COLUMN `fcra_registration_number` VARCHAR(100) DEFAULT NULL',
    'SELECT ''Column fcra_registration_number already exists'' AS Info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add years_of_experience if not exists
SET @column_check = (SELECT COUNT(*) 
                     FROM INFORMATION_SCHEMA.COLUMNS 
                     WHERE TABLE_SCHEMA = @dbname 
                     AND TABLE_NAME = @tablename 
                     AND COLUMN_NAME = 'years_of_experience');

SET @query = IF(@column_check = 0,
    'ALTER TABLE `partners` ADD COLUMN `years_of_experience` INT DEFAULT NULL COMMENT ''Years of experience in skill building''',
    'SELECT ''Column years_of_experience already exists'' AS Info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Verify columns were added
SELECT 
    'Verification: Partner table columns' AS Info;

SELECT 
    COLUMN_NAME, 
    DATA_TYPE, 
    COLUMN_TYPE, 
    IS_NULLABLE, 
    COLUMN_COMMENT
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = @dbname 
AND TABLE_NAME = @tablename
AND COLUMN_NAME IN (
    'region',
    'contact_person_2_name',
    'contact_person_2_mobile',
    'date_of_incorporation',
    'legal_status',
    'registered_as',
    'fcra_registration_number',
    'years_of_experience'
)
ORDER BY ORDINAL_POSITION;

-- =====================================================
-- END OF MIGRATION
-- =====================================================
