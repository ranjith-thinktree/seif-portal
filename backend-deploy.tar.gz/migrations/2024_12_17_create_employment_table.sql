-- Migration: Create employment/placement table
-- Date: 2024-12-17
-- Description: 
--   Create table to track student employment/placement data
--   Partners upload employment data for students using partner_student_id

-- ==============================================================================
-- CREATE EMPLOYMENT TABLE
-- ==============================================================================

CREATE TABLE IF NOT EXISTS employment (
  -- Primary identifiers
  id VARCHAR(36) PRIMARY KEY COMMENT 'UUID primary key',
  
  -- Foreign keys
  student_id VARCHAR(36) NOT NULL COMMENT 'Links to students.id (our internal UUID)',
  partner_id VARCHAR(36) NOT NULL COMMENT 'Links to partners.id',
  data_upload_id VARCHAR(36) NULL COMMENT 'Links to data_uploads.id (employment upload batch)',
  
  -- Partner reference
  partner_student_id VARCHAR(100) NOT NULL COMMENT 'Partner original student ID (for matching)',
  
  -- Employment details
  employment_status ENUM('Employed', 'Self-Employed', 'Entrepreneur', 'Unemployed', 'Further Education') NOT NULL DEFAULT 'Employed' COMMENT 'Employment status',
  
  company_name VARCHAR(255) NULL COMMENT 'Name of the company or organization',
  company_location VARCHAR(255) NULL COMMENT 'Location of the company',
  
  date_of_joining DATE NULL COMMENT 'Date of joining (for employed) or Date of inception (for entrepreneur)',
  
  designation VARCHAR(255) NULL COMMENT 'Job designation/role',
  
  salary_per_month DECIMAL(10, 2) NULL COMMENT 'Monthly salary or income (in rupees)',
  
  -- Additional fields
  employment_type ENUM('Full-Time', 'Part-Time', 'Contract', 'Freelance', 'Internship') NULL COMMENT 'Type of employment',
  
  industry VARCHAR(255) NULL COMMENT 'Industry sector',
  
  job_profile TEXT NULL COMMENT 'Brief job description or profile',
  
  is_current_job BOOLEAN DEFAULT TRUE COMMENT 'Is this the current job or past employment?',
  
  -- Verification
  is_verified BOOLEAN DEFAULT FALSE COMMENT 'Has this employment been verified by admin?',
  verified_by VARCHAR(36) NULL COMMENT 'Admin user ID who verified',
  verified_at TIMESTAMP NULL COMMENT 'Verification timestamp',
  
  verification_remarks TEXT NULL COMMENT 'Admin remarks during verification',
  
  -- Supporting documents
  offer_letter_url VARCHAR(500) NULL COMMENT 'Offer letter document URL',
  payslip_url VARCHAR(500) NULL COMMENT 'Payslip/salary slip document URL',
  
  -- Metadata
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  -- Foreign key constraints
  CONSTRAINT fk_employment_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  CONSTRAINT fk_employment_partner FOREIGN KEY (partner_id) REFERENCES partners(id) ON DELETE CASCADE,
  CONSTRAINT fk_employment_upload FOREIGN KEY (data_upload_id) REFERENCES data_uploads(id) ON DELETE SET NULL,
  CONSTRAINT fk_employment_verified_by FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE SET NULL,
  
  -- Indexes for performance
  INDEX idx_student_id (student_id),
  INDEX idx_partner_id (partner_id),
  INDEX idx_partner_student_id (partner_student_id),
  INDEX idx_employment_status (employment_status),
  INDEX idx_is_verified (is_verified),
  INDEX idx_created_at (created_at),
  
  -- Composite index for matching during upload
  INDEX idx_partner_student_lookup (partner_id, partner_student_id),
  
  -- Unique constraint: One employment record per student per upload batch
  UNIQUE KEY unique_student_upload (student_id, data_upload_id)
  
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
COMMENT='Student employment/placement tracking table';

-- ==============================================================================
-- CREATE EMPLOYMENT_UPLOADS TABLE (Track employment upload batches)
-- ==============================================================================

CREATE TABLE IF NOT EXISTS employment_uploads (
  id VARCHAR(36) PRIMARY KEY COMMENT 'UUID primary key',
  
  partner_id VARCHAR(36) NOT NULL COMMENT 'Links to partners.id',
  
  file_name VARCHAR(255) NOT NULL COMMENT 'Original uploaded file name',
  file_url VARCHAR(500) NULL COMMENT 'S3/local file path',
  
  total_records INT DEFAULT 0 COMMENT 'Total employment records in file',
  records_processed INT DEFAULT 0 COMMENT 'Successfully processed records',
  records_failed INT DEFAULT 0 COMMENT 'Failed records (student not found)',
  
  status ENUM('pending', 'processing', 'completed', 'failed') DEFAULT 'pending',
  
  uploaded_by VARCHAR(36) NOT NULL COMMENT 'User ID who uploaded',
  
  error_log TEXT NULL COMMENT 'JSON array of errors during processing',
  
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  CONSTRAINT fk_employment_upload_partner FOREIGN KEY (partner_id) REFERENCES partners(id) ON DELETE CASCADE,
  CONSTRAINT fk_employment_upload_user FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE CASCADE,
  
  INDEX idx_partner_id (partner_id),
  INDEX idx_status (status),
  INDEX idx_created_at (created_at)
  
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
COMMENT='Employment data upload batches tracking';

-- ==============================================================================
-- ADD EMPLOYMENT_STATUS COLUMN TO STUDENTS TABLE
-- ==============================================================================

-- Add quick reference field to students table
ALTER TABLE students 
ADD COLUMN employment_status ENUM('Employed', 'Self-Employed', 'Entrepreneur', 'Unemployed', 'Further Education', 'Unknown') 
DEFAULT 'Unknown' 
COMMENT 'Current employment status (synced from employment table)'
AFTER training_status;

-- Add index
ALTER TABLE students 
ADD INDEX idx_employment_status (employment_status);

-- ==============================================================================
-- VERIFICATION QUERIES
-- ==============================================================================

-- Verify employment table created
SELECT 
  'employment table' AS check_item,
  CASE WHEN COUNT(*) > 0 THEN '✓ SUCCESS' ELSE '✗ FAILED' END AS status
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'employment';

-- Verify employment_uploads table created
SELECT 
  'employment_uploads table' AS check_item,
  CASE WHEN COUNT(*) > 0 THEN '✓ SUCCESS' ELSE '✗ FAILED' END AS status
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'employment_uploads';

-- Verify employment_status column added to students
SELECT 
  'employment_status in students' AS check_item,
  CASE WHEN COUNT(*) > 0 THEN '✓ SUCCESS' ELSE '✗ FAILED' END AS status
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'students'
  AND COLUMN_NAME = 'employment_status';

-- Show table structure
DESCRIBE employment;
DESCRIBE employment_uploads;

-- ==============================================================================
-- SAMPLE DATA FOR TESTING (Optional - Comment out for production)
-- ==============================================================================

/*
-- Insert sample employment record (after you have student data)
INSERT INTO employment (
  id, student_id, partner_id, partner_student_id,
  employment_status, company_name, company_location,
  date_of_joining, designation, salary_per_month,
  employment_type, is_current_job
) VALUES (
  UUID(),
  'student-uuid-here',
  'partner-uuid-here',
  'STU001',
  'Employed',
  'Google India',
  'Bangalore, Karnataka',
  '2024-01-15',
  'Software Engineer',
  50000.00,
  'Full-Time',
  TRUE
);
*/

-- ==============================================================================
-- ROLLBACK INSTRUCTIONS (IF NEEDED)
-- ==============================================================================

/*
-- To rollback this migration:

-- 1. Drop tables
DROP TABLE IF EXISTS employment;
DROP TABLE IF EXISTS employment_uploads;

-- 2. Remove employment_status from students
ALTER TABLE students DROP COLUMN employment_status;
*/

-- ==============================================================================
-- NOTES FOR DEVELOPERS
-- ==============================================================================

/*
Employment Upload Flow:

1. Partner downloads employment template
2. Partner fills data with partner_student_id (same as used in student upload)
3. Partner uploads employment CSV
4. Backend processes:
   a. Parse CSV
   b. For each row:
      - Match student by (partner_id + partner_student_id)
      - If student found → Insert into employment table
      - If student NOT found → Add to error log
   c. Create employment_uploads record with stats
5. Admin can verify employment records (is_verified flag)
6. Student's employment_status field gets updated automatically

Future Features:
- Multiple employment records per student (job changes)
- Document uploads (offer letter, payslips)
- Employment analytics dashboard
- Verification workflow for admins
*/
