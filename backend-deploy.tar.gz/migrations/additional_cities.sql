-- =====================================================
-- Additional Cities for Indian States
-- =====================================================
-- This script adds major cities for all Indian states
-- Run this after the main partner_onboarding_migration.sql
-- =====================================================

-- Get country ID for India
SET @india_id = (SELECT id FROM countries WHERE code = 'IN' LIMIT 1);

-- Get state IDs
SET @andhra_pradesh_id = (SELECT id FROM states WHERE code = 'AP' AND country_id = @india_id LIMIT 1);
SET @karnataka_id = (SELECT id FROM states WHERE code = 'KA' AND country_id = @india_id LIMIT 1);
SET @tamil_nadu_id = (SELECT id FROM states WHERE code = 'TN' AND country_id = @india_id LIMIT 1);
SET @telangana_id = (SELECT id FROM states WHERE code = 'TS' AND country_id = @india_id LIMIT 1);
SET @kerala_id = (SELECT id FROM states WHERE code = 'KL' AND country_id = @india_id LIMIT 1);
SET @delhi_id = (SELECT id FROM states WHERE code = 'DL' AND country_id = @india_id LIMIT 1);
SET @uttar_pradesh_id = (SELECT id FROM states WHERE code = 'UP' AND country_id = @india_id LIMIT 1);
SET @west_bengal_id = (SELECT id FROM states WHERE code = 'WB' AND country_id = @india_id LIMIT 1);
SET @gujarat_id = (SELECT id FROM states WHERE code = 'GJ' AND country_id = @india_id LIMIT 1);
SET @rajasthan_id = (SELECT id FROM states WHERE code = 'RJ' AND country_id = @india_id LIMIT 1);
SET @punjab_id = (SELECT id FROM states WHERE code = 'PB' AND country_id = @india_id LIMIT 1);
SET @haryana_id = (SELECT id FROM states WHERE code = 'HR' AND country_id = @india_id LIMIT 1);

-- Andhra Pradesh Cities
INSERT INTO cities (state_id, country_id, name, is_active) VALUES
(@andhra_pradesh_id, @india_id, 'Visakhapatnam', TRUE),
(@andhra_pradesh_id, @india_id, 'Vijayawada', TRUE),
(@andhra_pradesh_id, @india_id, 'Guntur', TRUE),
(@andhra_pradesh_id, @india_id, 'Nellore', TRUE),
(@andhra_pradesh_id, @india_id, 'Kurnool', TRUE),
(@andhra_pradesh_id, @india_id, 'Tirupati', TRUE);

-- Karnataka Cities
INSERT INTO cities (state_id, country_id, name, is_active) VALUES
(@karnataka_id, @india_id, 'Bangalore', TRUE),
(@karnataka_id, @india_id, 'Mysore', TRUE),
(@karnataka_id, @india_id, 'Mangalore', TRUE),
(@karnataka_id, @india_id, 'Hubli', TRUE),
(@karnataka_id, @india_id, 'Belgaum', TRUE),
(@karnataka_id, @india_id, 'Gulbarga', TRUE);

-- Tamil Nadu Cities
INSERT INTO cities (state_id, country_id, name, is_active) VALUES
(@tamil_nadu_id, @india_id, 'Chennai', TRUE),
(@tamil_nadu_id, @india_id, 'Coimbatore', TRUE),
(@tamil_nadu_id, @india_id, 'Madurai', TRUE),
(@tamil_nadu_id, @india_id, 'Tiruchirappalli', TRUE),
(@tamil_nadu_id, @india_id, 'Salem', TRUE),
(@tamil_nadu_id, @india_id, 'Tirunelveli', TRUE);

-- Telangana Cities
INSERT INTO cities (state_id, country_id, name, is_active) VALUES
(@telangana_id, @india_id, 'Hyderabad', TRUE),
(@telangana_id, @india_id, 'Warangal', TRUE),
(@telangana_id, @india_id, 'Nizamabad', TRUE),
(@telangana_id, @india_id, 'Khammam', TRUE),
(@telangana_id, @india_id, 'Karimnagar', TRUE);

-- Kerala Cities
INSERT INTO cities (state_id, country_id, name, is_active) VALUES
(@kerala_id, @india_id, 'Thiruvananthapuram', TRUE),
(@kerala_id, @india_id, 'Kochi', TRUE),
(@kerala_id, @india_id, 'Kozhikode', TRUE),
(@kerala_id, @india_id, 'Thrissur', TRUE),
(@kerala_id, @india_id, 'Kollam', TRUE),
(@kerala_id, @india_id, 'Kannur', TRUE);

-- Delhi Cities/Areas
INSERT INTO cities (state_id, country_id, name, is_active) VALUES
(@delhi_id, @india_id, 'New Delhi', TRUE),
(@delhi_id, @india_id, 'South Delhi', TRUE),
(@delhi_id, @india_id, 'North Delhi', TRUE),
(@delhi_id, @india_id, 'East Delhi', TRUE),
(@delhi_id, @india_id, 'West Delhi', TRUE),
(@delhi_id, @india_id, 'Central Delhi', TRUE);

-- Uttar Pradesh Cities
INSERT INTO cities (state_id, country_id, name, is_active) VALUES
(@uttar_pradesh_id, @india_id, 'Lucknow', TRUE),
(@uttar_pradesh_id, @india_id, 'Kanpur', TRUE),
(@uttar_pradesh_id, @india_id, 'Ghaziabad', TRUE),
(@uttar_pradesh_id, @india_id, 'Agra', TRUE),
(@uttar_pradesh_id, @india_id, 'Meerut', TRUE),
(@uttar_pradesh_id, @india_id, 'Varanasi', TRUE),
(@uttar_pradesh_id, @india_id, 'Allahabad', TRUE),
(@uttar_pradesh_id, @india_id, 'Noida', TRUE);

-- West Bengal Cities
INSERT INTO cities (state_id, country_id, name, is_active) VALUES
(@west_bengal_id, @india_id, 'Kolkata', TRUE),
(@west_bengal_id, @india_id, 'Howrah', TRUE),
(@west_bengal_id, @india_id, 'Durgapur', TRUE),
(@west_bengal_id, @india_id, 'Asansol', TRUE),
(@west_bengal_id, @india_id, 'Siliguri', TRUE);

-- Gujarat Cities
INSERT INTO cities (state_id, country_id, name, is_active) VALUES
(@gujarat_id, @india_id, 'Ahmedabad', TRUE),
(@gujarat_id, @india_id, 'Surat', TRUE),
(@gujarat_id, @india_id, 'Vadodara', TRUE),
(@gujarat_id, @india_id, 'Rajkot', TRUE),
(@gujarat_id, @india_id, 'Bhavnagar', TRUE),
(@gujarat_id, @india_id, 'Jamnagar', TRUE);

-- Rajasthan Cities
INSERT INTO cities (state_id, country_id, name, is_active) VALUES
(@rajasthan_id, @india_id, 'Jaipur', TRUE),
(@rajasthan_id, @india_id, 'Jodhpur', TRUE),
(@rajasthan_id, @india_id, 'Kota', TRUE),
(@rajasthan_id, @india_id, 'Udaipur', TRUE),
(@rajasthan_id, @india_id, 'Ajmer', TRUE),
(@rajasthan_id, @india_id, 'Bikaner', TRUE);

-- Punjab Cities
INSERT INTO cities (state_id, country_id, name, is_active) VALUES
(@punjab_id, @india_id, 'Ludhiana', TRUE),
(@punjab_id, @india_id, 'Amritsar', TRUE),
(@punjab_id, @india_id, 'Jalandhar', TRUE),
(@punjab_id, @india_id, 'Patiala', TRUE),
(@punjab_id, @india_id, 'Bathinda', TRUE);

-- Haryana Cities
INSERT INTO cities (state_id, country_id, name, is_active) VALUES
(@haryana_id, @india_id, 'Faridabad', TRUE),
(@haryana_id, @india_id, 'Gurgaon', TRUE),
(@haryana_id, @india_id, 'Hisar', TRUE),
(@haryana_id, @india_id, 'Rohtak', TRUE),
(@haryana_id, @india_id, 'Panipat', TRUE);

-- =====================================================
-- Verification Query
-- =====================================================
-- Run this to check how many cities were added per state
SELECT 
  s.name as state_name,
  COUNT(c.id) as city_count
FROM states s
LEFT JOIN cities c ON c.state_id = s.id
WHERE s.country_id = @india_id
GROUP BY s.id, s.name
ORDER BY city_count DESC;
