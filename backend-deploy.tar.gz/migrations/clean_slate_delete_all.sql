-- ================================================================
-- CLEAN SLATE: Delete All Partners & Centers
-- ================================================================
-- Purpose: Delete existing data to re-upload with ORG format
-- Date: December 18, 2025
-- 
-- ⚠️ WARNING: This will delete:
--    - 8 partners
--    - 371 centers
--    - Any linked students/batches (if exist)
-- 
-- ✅ SAFE IF: No students or batches exist
-- ================================================================

-- ================================================================
-- STEP 1: Create Backup (SAFETY FIRST!)
-- ================================================================

DROP TABLE IF EXISTS partners_backup_clean_slate;
CREATE TABLE partners_backup_clean_slate AS SELECT * FROM partners;

DROP TABLE IF EXISTS centers_backup_clean_slate;
CREATE TABLE centers_backup_clean_slate AS SELECT * FROM centers;

SELECT 
    'BACKUP CREATED' as status,
    (SELECT COUNT(*) FROM partners_backup_clean_slate) as partners_backed_up,
    (SELECT COUNT(*) FROM centers_backup_clean_slate) as centers_backed_up;

-- ================================================================
-- STEP 2: Delete Related Data (if exists)
-- ================================================================

-- Delete students (if any)
DELETE FROM students WHERE center_id IN (SELECT id FROM centers);
SELECT 'STUDENTS DELETED' as status, ROW_COUNT() as rows_deleted;

-- Delete batches (if any)
DELETE FROM batches WHERE center_id IN (SELECT id FROM centers);
SELECT 'BATCHES DELETED' as status, ROW_COUNT() as rows_deleted;

-- Delete center-course relationships
DELETE FROM center_courses WHERE center_id IN (SELECT id FROM centers);
SELECT 'CENTER COURSES DELETED' as status, ROW_COUNT() as rows_deleted;

-- Delete uploaded centers (if any)
DELETE FROM uploaded_centers WHERE partner_id IN (SELECT id FROM partners);
SELECT 'UPLOADED CENTERS DELETED' as status, ROW_COUNT() as rows_deleted;

-- Delete uploaded students (if any)
DELETE FROM uploaded_students WHERE uploaded_center_id IN (
    SELECT id FROM uploaded_centers WHERE partner_id IN (SELECT id FROM partners)
);
SELECT 'UPLOADED STUDENTS DELETED' as status, ROW_COUNT() as rows_deleted;

-- Delete uploaded batches (if any)
DELETE FROM uploaded_batches WHERE uploaded_center_id IN (
    SELECT id FROM uploaded_centers WHERE partner_id IN (SELECT id FROM partners)
);
SELECT 'UPLOADED BATCHES DELETED' as status, ROW_COUNT() as rows_deleted;

-- Delete upload change logs (if any)
DELETE FROM upload_change_logs WHERE upload_id IN (
    SELECT id FROM data_uploads WHERE partner_id IN (SELECT id FROM partners)
);
SELECT 'UPLOAD CHANGE LOGS DELETED' as status, ROW_COUNT() as rows_deleted;

-- Delete data uploads (if any)
DELETE FROM data_uploads WHERE partner_id IN (SELECT id FROM partners);
SELECT 'DATA UPLOADS DELETED' as status, ROW_COUNT() as rows_deleted;

-- ================================================================
-- STEP 3: Delete Centers
-- ================================================================

DELETE FROM centers;
SELECT 
    'CENTERS DELETED' as status, 
    ROW_COUNT() as rows_deleted,
    (SELECT COUNT(*) FROM centers) as remaining_count;

-- ================================================================
-- STEP 4: Delete Partner-State Relationships
-- ================================================================

DELETE FROM partner_state_presence WHERE partner_id IN (SELECT id FROM partners);
SELECT 'PARTNER STATE PRESENCE DELETED' as status, ROW_COUNT() as rows_deleted;

-- ================================================================
-- STEP 5: Delete Partner Users
-- ================================================================

DELETE FROM users WHERE partner_id IN (SELECT id FROM partners);
SELECT 'PARTNER USERS DELETED' as status, ROW_COUNT() as rows_deleted;

-- ================================================================
-- STEP 6: Delete Partners
-- ================================================================

DELETE FROM partners;
SELECT 
    'PARTNERS DELETED' as status, 
    ROW_COUNT() as rows_deleted,
    (SELECT COUNT(*) FROM partners) as remaining_count;

-- ================================================================
-- STEP 7: Reset Auto-increment (Clean slate for IDs)
-- ================================================================

-- This ensures next partner gets ORG-0001
-- No actual auto-increment on partner_id, but good practice
ALTER TABLE partners AUTO_INCREMENT = 1;
ALTER TABLE centers AUTO_INCREMENT = 1;

SELECT 'AUTO INCREMENT RESET' as status;

-- ================================================================
-- STEP 8: Verification
-- ================================================================

SELECT '==========================================' as separator
UNION ALL
SELECT 'DELETION COMPLETE - VERIFICATION'
UNION ALL
SELECT '==========================================='
UNION ALL
SELECT CONCAT('Partners remaining: ', COUNT(*)) FROM partners
UNION ALL
SELECT CONCAT('Centers remaining: ', COUNT(*)) FROM centers
UNION ALL
SELECT CONCAT('Students remaining: ', COUNT(*)) FROM students
UNION ALL
SELECT CONCAT('Batches remaining: ', COUNT(*)) FROM batches
UNION ALL
SELECT '==========================================';

-- Expected output: All counts should be 0

-- ================================================================
-- STEP 9: Verify Backup Integrity
-- ================================================================

SELECT 
    'BACKUP VERIFICATION' as check_type,
    (SELECT COUNT(*) FROM partners_backup_clean_slate) as partners_in_backup,
    (SELECT COUNT(*) FROM centers_backup_clean_slate) as centers_in_backup,
    CASE 
        WHEN (SELECT COUNT(*) FROM partners_backup_clean_slate) = 8 
         AND (SELECT COUNT(*) FROM centers_backup_clean_slate) = 371
        THEN '✅ BACKUP INTACT - Can restore if needed'
        ELSE '⚠️ BACKUP INCOMPLETE - Check manually'
    END as backup_status;

-- ================================================================
-- ROLLBACK SCRIPT (Use if you need to restore)
-- ================================================================
-- 
-- To restore from backup:
-- 
-- INSERT INTO partners SELECT * FROM partners_backup_clean_slate;
-- INSERT INTO centers SELECT * FROM centers_backup_clean_slate;
-- 
-- SELECT COUNT(*) FROM partners;  -- Should be 8
-- SELECT COUNT(*) FROM centers;   -- Should be 371
-- 
-- ================================================================

-- ================================================================
-- SUCCESS MESSAGE
-- ================================================================

SELECT '==========================================' as message
UNION ALL
SELECT '✅ DATABASE CLEANED SUCCESSFULLY!'
UNION ALL
SELECT '==========================================='
UNION ALL
SELECT 'Next steps:'
UNION ALL
SELECT '1. Start backend server (npm start)'
UNION ALL
SELECT '2. Upload 8 partners (bulk upload)'
UNION ALL
SELECT '3. Upload 384 centers (bulk upload)'
UNION ALL
SELECT ''
UNION ALL
SELECT '🎉 All new uploads will have ORG format!'
UNION ALL
SELECT '==========================================';
