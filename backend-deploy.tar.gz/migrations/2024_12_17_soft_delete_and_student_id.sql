-- Migration: Add soft delete and rename student_id to partner_student_id
-- Date: 2024-12-17
-- Description: 
--   1. Add deleted_at column for soft delete functionality
--   2. Rename student_id to partner_student_id for clarity
--   3. Add composite unique key for (partner_id, partner_student_id)
--   4. Ensure data integrity during migration

-- ==============================================================================
-- PART 1: ADD SOFT DELETE COLUMN TO data_uploads
-- ==============================================================================

-- Add deleted_at column to data_uploads table
ALTER TABLE data_uploads 
ADD COLUMN deleted_at TIMESTAMP NULL DEFAULT NULL AFTER updated_at,
ADD INDEX idx_deleted_at (deleted_at);

-- Add comment to explain soft delete
ALTER TABLE data_uploads 
MODIFY COLUMN deleted_at TIMESTAMP NULL DEFAULT NULL 
COMMENT 'Soft delete timestamp - when V1 is superseded by V2';

-- ==============================================================================
-- PART 2: RENAME student_id TO partner_student_id IN ALL TABLES
-- ==============================================================================

-- Important: We keep our internal UUID 'id' column as primary key
-- We rename 'student_id' (partner's original ID) to 'partner_student_id' for clarity

-- -----------------------------------------------------------------------------
-- 2.1: STAGING TABLES (uploaded_students)
-- -----------------------------------------------------------------------------

-- Check if column exists before renaming (idempotent migration)
SET @col_exists = (
  SELECT COUNT(*) 
  FROM INFORMATION_SCHEMA.COLUMNS 
  WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'uploaded_students' 
    AND COLUMN_NAME = 'student_id'
);

-- Rename column if it exists
SET @sql = IF(@col_exists > 0,
  'ALTER TABLE uploaded_students CHANGE COLUMN student_id partner_student_id VARCHAR(100) DEFAULT NULL COMMENT "Partner\'s original student ID (e.g., STU001)"',
  'SELECT "Column student_id already renamed or does not exist" AS message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add composite unique key for (partner_id, partner_student_id) in staging
-- Drop existing index if it exists
SET @index_exists = (
  SELECT COUNT(*)
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'uploaded_students'
    AND INDEX_NAME = 'unique_partner_student'
);

SET @sql = IF(@index_exists > 0,
  'ALTER TABLE uploaded_students DROP INDEX unique_partner_student',
  'SELECT "Index does not exist" AS message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Create new composite unique key
ALTER TABLE uploaded_students 
ADD CONSTRAINT unique_partner_student UNIQUE KEY (partner_id, partner_student_id);

-- -----------------------------------------------------------------------------
-- 2.2: PRODUCTION TABLES (students)
-- -----------------------------------------------------------------------------

-- Check if column exists in production table
SET @col_exists_prod = (
  SELECT COUNT(*) 
  FROM INFORMATION_SCHEMA.COLUMNS 
  WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'students' 
    AND COLUMN_NAME = 'student_id'
);

-- Rename column if it exists
SET @sql = IF(@col_exists_prod > 0,
  'ALTER TABLE students CHANGE COLUMN student_id partner_student_id VARCHAR(100) DEFAULT NULL COMMENT "Partner\'s original student ID (e.g., STU001)"',
  'SELECT "Column student_id already renamed in students table" AS message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add composite unique key for (partner_id, partner_student_id) in production
SET @index_exists_prod = (
  SELECT COUNT(*)
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'students'
    AND INDEX_NAME = 'unique_partner_student'
);

SET @sql = IF(@index_exists_prod > 0,
  'ALTER TABLE students DROP INDEX unique_partner_student',
  'SELECT "Index does not exist in students table" AS message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Create composite unique key in production
ALTER TABLE students 
ADD CONSTRAINT unique_partner_student UNIQUE KEY (partner_id, partner_student_id);

-- ==============================================================================
-- PART 3: UPDATE data_edit_logs TABLE (if exists)
-- ==============================================================================

-- Check if data_edit_logs table exists and has field_name column
SET @table_exists = (
  SELECT COUNT(*) 
  FROM INFORMATION_SCHEMA.TABLES 
  WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'data_edit_logs'
);

-- Update field_name references from 'student_id' to 'partner_student_id'
SET @sql = IF(@table_exists > 0,
  'UPDATE data_edit_logs SET field_name = "partner_student_id" WHERE field_name = "student_id"',
  'SELECT "data_edit_logs table does not exist" AS message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ==============================================================================
-- PART 4: ADD INDEXES FOR PERFORMANCE
-- ==============================================================================

-- Add index on partner_student_id for faster lookups in staging
ALTER TABLE uploaded_students 
ADD INDEX idx_partner_student_id (partner_student_id);

-- Add index on partner_student_id for faster lookups in production
ALTER TABLE students 
ADD INDEX idx_partner_student_id (partner_student_id);

-- Add composite index for partner_id + partner_student_id lookups
ALTER TABLE uploaded_students 
ADD INDEX idx_partner_lookup (partner_id, partner_student_id);

ALTER TABLE students 
ADD INDEX idx_partner_lookup (partner_id, partner_student_id);

-- ==============================================================================
-- PART 5: VERIFICATION QUERIES
-- ==============================================================================

-- Verify deleted_at column was added
SELECT 
  'deleted_at column' AS check_item,
  CASE WHEN COUNT(*) > 0 THEN '✓ SUCCESS' ELSE '✗ FAILED' END AS status
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'data_uploads'
  AND COLUMN_NAME = 'deleted_at';

-- Verify student_id was renamed in uploaded_students
SELECT 
  'partner_student_id in uploaded_students' AS check_item,
  CASE WHEN COUNT(*) > 0 THEN '✓ SUCCESS' ELSE '✗ FAILED' END AS status
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'uploaded_students'
  AND COLUMN_NAME = 'partner_student_id';

-- Verify student_id was renamed in students
SELECT 
  'partner_student_id in students' AS check_item,
  CASE WHEN COUNT(*) > 0 THEN '✓ SUCCESS' ELSE '✗ FAILED' END AS status
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'students'
  AND COLUMN_NAME = 'partner_student_id';

-- Verify unique constraint exists in uploaded_students
SELECT 
  'unique_partner_student constraint in uploaded_students' AS check_item,
  CASE WHEN COUNT(*) > 0 THEN '✓ SUCCESS' ELSE '✗ FAILED' END AS status
FROM INFORMATION_SCHEMA.STATISTICS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'uploaded_students'
  AND INDEX_NAME = 'unique_partner_student';

-- Verify unique constraint exists in students
SELECT 
  'unique_partner_student constraint in students' AS check_item,
  CASE WHEN COUNT(*) > 0 THEN '✓ SUCCESS' ELSE '✗ FAILED' END AS status
FROM INFORMATION_SCHEMA.STATISTICS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'students'
  AND INDEX_NAME = 'unique_partner_student';

-- ==============================================================================
-- ROLLBACK INSTRUCTIONS (IF NEEDED)
-- ==============================================================================

/*
-- To rollback this migration:

-- 1. Remove deleted_at column
ALTER TABLE data_uploads DROP COLUMN deleted_at;

-- 2. Rename partner_student_id back to student_id in staging
ALTER TABLE uploaded_students 
DROP INDEX unique_partner_student,
CHANGE COLUMN partner_student_id student_id VARCHAR(100) DEFAULT NULL;

-- 3. Rename partner_student_id back to student_id in production
ALTER TABLE students 
DROP INDEX unique_partner_student,
CHANGE COLUMN partner_student_id student_id VARCHAR(100) DEFAULT NULL;

-- 4. Update data_edit_logs
UPDATE data_edit_logs 
SET field_name = 'student_id' 
WHERE field_name = 'partner_student_id';
*/

-- ==============================================================================
-- NOTES FOR DEVELOPERS
-- ==============================================================================

/*
After running this migration:

1. Backend Code Changes Required:
   - Update all SQL queries: student_id → partner_student_id
   - Update upload.service.js, partner.service.js, review.service.js
   - Update controllers and routes
   - Update excelHandler.js column mapping

2. Frontend Code Changes Required:
   - Update API response mappings
   - Update AG Grid column definitions
   - Update form field names
   - Update validation logic

3. Testing Required:
   - Test upload with partner_student_id
   - Test duplicate detection (same partner_student_id within partner)
   - Test soft delete (deleted_at is set, not hard delete)
   - Test resubmission (V1 soft deleted when V2 created)
   - Test employment data mapping (future feature)

4. Database Backup:
   - Always backup before running migrations!
   - Test in staging environment first
   - Verify data integrity after migration
*/
