-- ================================================================
-- PRODUCTION-READY ID FORMAT MIGRATION: PART → ORG
-- ================================================================
-- Date: December 18, 2025
-- Purpose: Change partner and center ID format from PART to ORG
-- Current format: PART-0001, PART0002-AMBU-0011
-- New format: ORG-0001, ORG0002-AMBU-0011
-- 
-- CRITICAL: This migration updates 8 partners and 371 centers
-- ================================================================

-- STEP 1: Create backup tables (SAFETY FIRST!)
-- ================================================================

DROP TABLE IF EXISTS partners_backup_20251218;
CREATE TABLE partners_backup_20251218 AS SELECT * FROM partners;

DROP TABLE IF EXISTS centers_backup_20251218;
CREATE TABLE centers_backup_20251218 AS SELECT * FROM centers;

SELECT 
    'BACKUP CREATED' as status,
    (SELECT COUNT(*) FROM partners_backup_20251218) as partners_backed_up,
    (SELECT COUNT(*) FROM centers_backup_20251218) as centers_backed_up;

-- ================================================================
-- STEP 2: Update Partner IDs (PART-0001 → ORG-0001)
-- ================================================================

-- Update partners table
UPDATE partners 
SET partner_id = CONCAT('ORG-', SUBSTRING(partner_id, 6))
WHERE partner_id LIKE 'PART-%';

-- Verify partner update
SELECT 
    'PARTNERS UPDATED' as status,
    COUNT(*) as total_updated,
    GROUP_CONCAT(partner_id ORDER BY partner_id) as new_partner_ids
FROM partners 
WHERE partner_id LIKE 'ORG-%';

-- ================================================================
-- STEP 3: Update Center IDs (PART0001-DONB-0051 → ORG0001-DONB-0051)
-- ================================================================

-- Update centers table - Replace PART with ORG in center_id
UPDATE centers 
SET center_id = CONCAT('ORG', SUBSTRING(center_id, 5))
WHERE center_id LIKE 'PART%';

-- Verify center update
SELECT 
    'CENTERS UPDATED' as status,
    COUNT(*) as total_updated,
    COUNT(DISTINCT SUBSTRING_INDEX(center_id, '-', 1)) as unique_partner_prefixes
FROM centers 
WHERE center_id LIKE 'ORG%';

-- ================================================================
-- STEP 4: Validation Checks
-- ================================================================

-- Check 1: Verify all partners migrated
SELECT 
    'VALIDATION: Partners' as check_name,
    CASE 
        WHEN COUNT(*) = 0 THEN '✅ PASS - No old PART format found'
        ELSE '❌ FAIL - Old PART format still exists'
    END as result,
    COUNT(*) as old_format_count
FROM partners 
WHERE partner_id LIKE 'PART-%';

-- Check 2: Verify all centers migrated
SELECT 
    'VALIDATION: Centers' as check_name,
    CASE 
        WHEN COUNT(*) = 0 THEN '✅ PASS - No old PART format found'
        ELSE '❌ FAIL - Old PART format still exists'
    END as result,
    COUNT(*) as old_format_count
FROM centers 
WHERE center_id LIKE 'PART%';

-- Check 3: Verify partner count is unchanged
SELECT 
    'VALIDATION: Partner Count' as check_name,
    CASE 
        WHEN COUNT(*) = (SELECT COUNT(*) FROM partners_backup_20251218)
        THEN '✅ PASS - Partner count matches backup'
        ELSE '❌ FAIL - Partner count mismatch'
    END as result,
    COUNT(*) as current_count,
    (SELECT COUNT(*) FROM partners_backup_20251218) as backup_count
FROM partners;

-- Check 4: Verify center count is unchanged
SELECT 
    'VALIDATION: Center Count' as check_name,
    CASE 
        WHEN COUNT(*) = (SELECT COUNT(*) FROM centers_backup_20251218)
        THEN '✅ PASS - Center count matches backup'
        ELSE '❌ FAIL - Center count mismatch'
    END as result,
    COUNT(*) as current_count,
    (SELECT COUNT(*) FROM centers_backup_20251218) as backup_count
FROM centers;

-- ================================================================
-- STEP 5: Sample Data Verification
-- ================================================================

-- Show sample of migrated partners
SELECT 
    'SAMPLE: Partners' as data_type,
    partner_id as new_id,
    name as partner_name
FROM partners 
WHERE partner_id LIKE 'ORG-%'
ORDER BY partner_id
LIMIT 10;

-- Show sample of migrated centers
SELECT 
    'SAMPLE: Centers' as data_type,
    center_id as new_id,
    center_name,
    partner_id
FROM centers c
JOIN partners p ON c.partner_id = p.id
WHERE c.center_id LIKE 'ORG%'
ORDER BY c.center_id
LIMIT 20;

-- ================================================================
-- STEP 6: Partner-Center Relationship Verification
-- ================================================================

-- Verify each partner has correct center prefix
SELECT 
    p.partner_id as partner_new_id,
    p.name as partner_name,
    COUNT(c.id) as center_count,
    GROUP_CONCAT(DISTINCT SUBSTRING_INDEX(c.center_id, '-', 1) SEPARATOR ', ') as center_prefixes,
    CASE 
        WHEN CONCAT('ORG', SUBSTRING(p.partner_id, 5)) = SUBSTRING_INDEX(MIN(c.center_id), '-', 1)
        THEN '✅ MATCH'
        ELSE '❌ MISMATCH'
    END as prefix_match_status
FROM partners p
LEFT JOIN centers c ON p.id = c.partner_id
WHERE p.partner_id LIKE 'ORG-%'
GROUP BY p.id, p.partner_id, p.name
ORDER BY p.partner_id;

-- ================================================================
-- ROLLBACK SCRIPT (Use if migration fails)
-- ================================================================
-- IMPORTANT: Save this separately before running migration
-- 
-- To rollback:
-- DROP TABLE partners;
-- DROP TABLE centers;
-- CREATE TABLE partners AS SELECT * FROM partners_backup_20251218;
-- CREATE TABLE centers AS SELECT * FROM centers_backup_20251218;
-- 
-- Then restore indexes and constraints
-- ================================================================

-- ================================================================
-- FINAL MIGRATION SUMMARY
-- ================================================================

SELECT '===========================================' as line
UNION ALL
SELECT 'MIGRATION COMPLETE SUMMARY'
UNION ALL
SELECT '==========================================='
UNION ALL
SELECT CONCAT('Partners migrated: ', COUNT(*)) 
FROM partners WHERE partner_id LIKE 'ORG-%'
UNION ALL
SELECT CONCAT('Centers migrated: ', COUNT(*)) 
FROM centers WHERE center_id LIKE 'ORG%'
UNION ALL
SELECT '==========================================';

-- Display all new partner IDs
SELECT 
    partner_id as new_partner_id,
    name as partner_name,
    (SELECT COUNT(*) FROM centers WHERE partner_id = p.id) as center_count
FROM partners p
WHERE partner_id LIKE 'ORG-%'
ORDER BY partner_id;
