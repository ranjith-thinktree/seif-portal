-- Add new courses for center creation
-- Date: 2025-12-09

INSERT INTO courses (id, course_name, course_code, description, duration_months, is_active) VALUES
(UUID(), 'Electrician', 'ELEC-002', 'Electrician training course', 6, 1),
(UUID(), 'Industrial Centre', 'INDC-001', 'Industrial Centre training course', 12, 1),
(UUID(), 'TOT', 'TOT-001', 'Training of Trainers course', 3, 1)
ON DUPLICATE KEY UPDATE course_name = VALUES(course_name);

-- Note: 'Solar' already exists in the database
-- Note: 'Electrical' and 'Industrial Automation' also exist
