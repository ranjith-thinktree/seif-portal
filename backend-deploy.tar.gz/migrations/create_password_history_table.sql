-- =====================================================
-- Password History Table Migration
-- This script creates only the password_history table
-- (columns already exist in users table)
-- =====================================================

-- Create Password History Table
CREATE TABLE IF NOT EXISTS password_history (
  id CHAR(36) PRIMARY KEY,
  user_id CHAR(36) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_user_created (user_id, created_at DESC),
  CONSTRAINT fk_password_history_user FOREIGN KEY (user_id) 
    REFERENCES users(id) 
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci
COMMENT 'Stores password history to prevent reuse of recent passwords';

-- Verify the table was created
SELECT 'Password history table created successfully!' as status;
DESCRIBE password_history;
