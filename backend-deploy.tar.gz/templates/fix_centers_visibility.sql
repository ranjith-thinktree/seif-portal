-- Quick Fix Script: Ensure centers are visible in analytics
-- Run this in your MySQL database

-- 1. Check current center status
SELECT 
    center_id, 
    center_name, 
    status, 
    approval_status,
    partner_id
FROM centers
WHERE center_id IN ('C001', 'C002', 'C003', 'C004', 'C005', 'C006');

-- 2. Update centers to active status (if needed)
UPDATE centers 
SET status = 'active', 
    approval_status = 'approved'
WHERE center_id IN ('C001', 'C002', 'C003', 'C004', 'C005', 'C006');

-- 3. Verify the update
SELECT 
    center_id, 
    center_name, 
    status, 
    approval_status,
    partner_id
FROM centers
WHERE center_id IN ('C001', 'C002', 'C003', 'C004', 'C005', 'C006');

-- 4. Check if any students exist for these centers
SELECT 
    c.center_id,
    c.center_name,
    COUNT(s.id) as student_count
FROM centers c
LEFT JOIN students s ON c.id = s.center_id
WHERE c.center_id IN ('C001', 'C002', 'C003', 'C004', 'C005', 'C006')
GROUP BY c.center_id, c.center_name;
