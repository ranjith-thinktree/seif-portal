-- Fix missing notifications for partner user
-- This adds the notifications that should have been created when admin approved/rejected centers

-- Insert notification for approved Pune Training Center
INSERT INTO notifications (
  id, 
  recipient_id, 
  type, 
  alert_type, 
  title, 
  message, 
  related_entity_type, 
  related_entity_id, 
  sent_via, 
  is_read,
  created_at
) VALUES (
  'notif-001-pune-approved',
  'a0000000-0000-0000-0000-000000000005',  -- Partner User ID
  'DATA_APPROVED',
  'success',
  'Center Approved',
  'Center "Pune Training Center" has been approved and is now active.',
  'center',
  'a4c0ff4c-dd92-4ca0-b2db-eecc5eb7f533',  -- Approved center ID
  'in_app',
  0,
  '2025-11-26 08:28:56'
);

-- Insert notification for approved Bangalore Automation Center
INSERT INTO notifications (
  id, 
  recipient_id, 
  type, 
  alert_type, 
  title, 
  message, 
  related_entity_type, 
  related_entity_id, 
  sent_via, 
  is_read,
  created_at
) VALUES (
  'notif-002-bangalore-approved',
  'a0000000-0000-0000-0000-000000000005',  -- Partner User ID
  'DATA_APPROVED',
  'success',
  'Center Approved',
  'Center "Bangalore Automation Center" has been approved and is now active.',
  'center',
  'ece3567f-3bd2-4fcd-9a1e-7f3054bc4dd2',  -- Approved center ID
  'in_app',
  0,
  '2025-11-26 08:30:08'
);

-- Insert notification for rejected Mumbai Solar Hub
INSERT INTO notifications (
  id, 
  recipient_id, 
  type, 
  alert_type, 
  title, 
  message, 
  remark,
  related_entity_type, 
  related_entity_id, 
  sent_via, 
  is_read,
  created_at
) VALUES (
  'notif-003-mumbai-rejected',
  'a0000000-0000-0000-0000-000000000005',  -- Partner User ID
  'DATA_REJECTED',
  'error',
  'Center Rejected',
  'Center "Mumbai Solar Hub" has been rejected. Reason: Not a Good',
  'Check the data',
  'uploaded_center',
  'e781fee0-c89f-11f0-94bf-00410e2b5e6e',  -- Rejected uploaded center ID
  'in_app',
  0,
  '2025-11-26 08:30:40'
);
