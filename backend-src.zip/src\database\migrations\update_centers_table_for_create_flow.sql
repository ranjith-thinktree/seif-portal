-- Migration: Update centers table for Create Center flow
-- Date: 2025-12-09
-- Description: Add foreign keys for country/state/city and partner_type field

-- Add foreign key columns for global location data
ALTER TABLE centers
ADD COLUMN country_id INT NULL COMMENT 'Reference to countries table' AFTER partner_id,
ADD COLUMN state_id INT NULL COMMENT 'Reference to states table' AFTER region,
ADD COLUMN city_id INT NULL COMMENT 'Reference to cities table' AFTER state_id;

-- Add partner_type field (will be auto-filled from partner's organization_type)
ALTER TABLE centers
ADD COLUMN partner_type VARCHAR(50) NULL COMMENT 'Type of partner organization (NGO, Corporate, Govt, Private)' AFTER partner_id;

-- Add indexes for better query performance
ALTER TABLE centers
ADD INDEX idx_country_id (country_id),
ADD INDEX idx_state_id (state_id),
ADD INDEX idx_city_id (city_id),
ADD INDEX idx_partner_type (partner_type);

-- Add foreign key constraints
ALTER TABLE centers
ADD CONSTRAINT fk_centers_country FOREIGN KEY (country_id) REFERENCES countries(id) ON DELETE SET NULL,
ADD CONSTRAINT fk_centers_state FOREIGN KEY (state_id) REFERENCES states(id) ON DELETE SET NULL,
ADD CONSTRAINT fk_centers_city FOREIGN KEY (city_id) REFERENCES cities(id) ON DELETE SET NULL;

-- Update status enum to include 'closed' option
ALTER TABLE centers
MODIFY COLUMN status VARCHAR(50) DEFAULT 'active' COMMENT 'active, inactive, closed';

-- Update center_type to include COE option
ALTER TABLE centers
MODIFY COLUMN center_type VARCHAR(100) DEFAULT NULL COMMENT 'Short term, ITI, Polytechnic, COE';

-- Update region to include UT (Union Territory) option
ALTER TABLE centers
MODIFY COLUMN region VARCHAR(100) DEFAULT NULL COMMENT 'N, S, E, W, UT';

-- Add country column as text field (for backward compatibility)
ALTER TABLE centers
ADD COLUMN country VARCHAR(100) NULL COMMENT 'Country name (text)' AFTER state;

-- Note: center_courses junction table already exists for many-to-many relationship with courses
