-- SEIF Portal - Initial Test Users
-- Run this SQL in phpMyAdmin after importing the main database schema

-- Note: All passwords are hashed with bcrypt
-- Default password for all test users: "Password123"
-- Bcrypt hash: $2a$10$Xe9b2N0WR/N1H8ftEcaQp.B1CBGt.JUSdR2/kjDsPDMULCugpTJFG

-- Clear existing users (optional, only for fresh start)
-- DELETE FROM users;

-- Insert Super Admin
INSERT INTO users (
  id, 
  email, 
  password_hash, 
  full_name, 
  mobile_number, 
  role, 
  partner_id, 
  status, 
  created_at, 
  updated_at
) VALUES (
  'a0000000-0000-0000-0000-000000000001',
  'superadmin@seif.org',
  '$2a$10$Xe9b2N0WR/N1H8ftEcaQp.B1CBGt.JUSdR2/kjDsPDMULCugpTJFG',
  'Super Admin',
  '9876543210',
  'SUPER_ADMIN',
  NULL,
  'active',
  NOW(),
  NOW()
);

-- Insert Admin
INSERT INTO users (
  id, 
  email, 
  password_hash, 
  full_name, 
  mobile_number, 
  role, 
  partner_id, 
  status, 
  created_at, 
  updated_at
) VALUES (
  'a0000000-0000-0000-0000-000000000002',
  'admin@seif.org',
  '$2a$10$Xe9b2N0WR/N1H8ftEcaQp.B1CBGt.JUSdR2/kjDsPDMULCugpTJFG',
  'Admin User',
  '9876543211',
  'ADMIN',
  NULL,
  'active',
  NOW(),
  NOW()
);

-- Insert SEIF Read-Only User
INSERT INTO users (
  id, 
  email, 
  password_hash, 
  full_name, 
  mobile_number, 
  role, 
  partner_id, 
  status, 
  created_at, 
  updated_at
) VALUES (
  'a0000000-0000-0000-0000-000000000003',
  'readonly@seif.org',
  '$2a$10$Xe9b2N0WR/N1H8ftEcaQp.B1CBGt.JUSdR2/kjDsPDMULCugpTJFG',
  'Read Only User',
  '9876543212',
  'SEIF_READONLY',
  NULL,
  'active',
  NOW(),
  NOW()
);

-- Insert ESSCI User
INSERT INTO users (
  id, 
  email, 
  password_hash, 
  full_name, 
  mobile_number, 
  role, 
  partner_id, 
  status, 
  created_at, 
  updated_at
) VALUES (
  'a0000000-0000-0000-0000-000000000004',
  'essci@seif.org',
  '$2a$10$Xe9b2N0WR/N1H8ftEcaQp.B1CBGt.JUSdR2/kjDsPDMULCugpTJFG',
  'ESSCI User',
  '9876543213',
  'ESSCI',
  NULL,
  'active',
  NOW(),
  NOW()
);

-- First, create a test partner
INSERT INTO partners (
  id,
  name,
  organization_type,
  contact_person,
  contact_email,
  contact_phone,
  city,
  state,
  country,
  status,
  created_at,
  updated_at
) VALUES (
  'b0000000-0000-0000-0000-000000000001',
  'Test Partner Organization',
  'Educational Institute',
  'Partner Contact Person',
  'contact@testpartner.org',
  '9876543214',
  'Mumbai',
  'Maharashtra',
  'India',
  'active',
  NOW(),
  NOW()
);

-- Insert Partner User (linked to the partner above)
INSERT INTO users (
  id, 
  email, 
  password_hash, 
  full_name, 
  mobile_number, 
  role, 
  partner_id, 
  status, 
  created_at, 
  updated_at
) VALUES (
  'a0000000-0000-0000-0000-000000000005',
  'partner@testpartner.org',
  '$2a$10$Xe9b2N0WR/N1H8ftEcaQp.B1CBGt.JUSdR2/kjDsPDMULCugpTJFG',
  'Partner User',
  '9876543215',
  'PARTNER',
  'b0000000-0000-0000-0000-000000000001',
  'active',
  NOW(),
  NOW()
);

-- Insert Inactive User (for testing)
INSERT INTO users (
  id, 
  email, 
  password_hash, 
  full_name, 
  mobile_number, 
  role, 
  partner_id, 
  status, 
  created_at, 
  updated_at
) VALUES (
  'a0000000-0000-0000-0000-000000000006',
  'inactive@seif.org',
  '$2a$10$Xe9b2N0WR/N1H8ftEcaQp.B1CBGt.JUSdR2/kjDsPDMULCugpTJFG',
  'Inactive User',
  '9876543216',
  'PARTNER',
  NULL,
  'inactive',
  NOW(),
  NOW()
);

-- Verify insertion
SELECT 
  email, 
  full_name, 
  role, 
  status,
  partner_id
FROM users
ORDER BY created_at DESC;

-- ===================================
-- TEST USER CREDENTIALS
-- ===================================
-- 
-- All users have the same password: Password123
-- 
-- 1. Super Admin
--    Email: superadmin@seif.org
--    Password: Password123
--    Role: SUPER_ADMIN
-- 
-- 2. Admin
--    Email: admin@seif.org
--    Password: Password123
--    Role: ADMIN
-- 
-- 3. Read Only
--    Email: readonly@seif.org
--    Password: Password123
--    Role: SEIF_READONLY
-- 
-- 4. ESSCI
--    Email: essci@seif.org
--    Password: Password123
--    Role: ESSCI
-- 
-- 5. Partner User
--    Email: partner@testpartner.org
--    Password: Password123
--    Role: PARTNER
--    Partner ID: b0000000-0000-0000-0000-000000000001
-- 
-- 6. Inactive User (should fail login)
--    Email: inactive@seif.org
--    Password: Password123
--    Status: inactive
-- 
-- ===================================
