-- ================================================================
-- SAFETY CHECK: Verify if deletion is safe
-- ================================================================
-- Run this BEFORE deleting partners/centers
-- ================================================================

-- Check 1: Students count
SELECT 
    'STUDENTS CHECK' as check_type,
    COUNT(*) as total_count,
    CASE 
        WHEN COUNT(*) = 0 THEN '✅ SAFE TO DELETE - No students'
        ELSE '⚠️ DANGER - Students exist! Will be deleted!'
    END as safety_status
FROM students;

-- Check 2: Batches count
SELECT 
    'BATCHES CHECK' as check_type,
    COUNT(*) as total_count,
    CASE 
        WHEN COUNT(*) = 0 THEN '✅ SAFE TO DELETE - No batches'
        ELSE '⚠️ DANGER - Batches exist! Will be deleted!'
    END as safety_status
FROM batches;

-- Check 3: Uploaded students count
SELECT 
    'UPLOADED STUDENTS CHECK' as check_type,
    COUNT(*) as total_count,
    CASE 
        WHEN COUNT(*) = 0 THEN '✅ SAFE TO DELETE - No uploaded students'
        ELSE '⚠️ DANGER - Uploaded students exist! Will be deleted!'
    END as safety_status
FROM uploaded_students;

-- Check 4: Data uploads count
SELECT 
    'DATA UPLOADS CHECK' as check_type,
    COUNT(*) as total_count,
    CASE 
        WHEN COUNT(*) = 0 THEN '✅ SAFE TO DELETE - No uploads'
        ELSE '⚠️ WARNING - Upload history exists'
    END as safety_status
FROM data_uploads;

-- Summary
SELECT '==========================================' as separator
UNION ALL
SELECT 'DELETION SAFETY SUMMARY'
UNION ALL
SELECT '==========================================='
UNION ALL
SELECT CONCAT('Partners to delete: ', COUNT(*)) FROM partners
UNION ALL
SELECT CONCAT('Centers to delete: ', COUNT(*)) FROM centers
UNION ALL
SELECT CONCAT('Students that will be lost: ', COUNT(*)) FROM students
UNION ALL
SELECT CONCAT('Batches that will be lost: ', COUNT(*)) FROM batches
UNION ALL
SELECT '==========================================';

-- ================================================================
-- IF ALL CHECKS SHOW ✅ SAFE, you can proceed with deletion
-- ================================================================
