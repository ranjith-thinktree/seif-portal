-- Migration: Add center_id column to centers table and generate IDs for existing centers
-- Date: 2025-12-10
-- Description: Adds center_id column with format PART0001-AMBU-0001

-- Step 1: Add center_id column
ALTER TABLE `centers` 
ADD COLUMN `center_id` VARCHAR(50) NULL UNIQUE AFTER `id`,
ADD INDEX `idx_center_id` (`center_id`);

-- Step 2: Update existing centers with generated center_ids
-- This will generate center_id based on: partner_id + first 4 chars of partner name + sequence number

DELIMITER $$

CREATE PROCEDURE generate_center_ids()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_center_id CHAR(36);
    DECLARE v_partner_id CHAR(36);
    DECLARE v_partner_name VARCHAR(255);
    DECLARE v_partner_id_str VARCHAR(20);
    DECLARE v_partner_prefix VARCHAR(4);
    DECLARE v_center_sequence INT;
    DECLARE v_new_center_id VARCHAR(50);
    
    DECLARE center_cursor CURSOR FOR 
        SELECT c.id, c.partner_id, p.name, p.partner_id 
        FROM centers c
        JOIN partners p ON c.partner_id = p.id
        WHERE c.center_id IS NULL
        ORDER BY c.partner_id, c.created_at;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    SET @current_partner = NULL;
    SET @sequence = 0;
    
    OPEN center_cursor;
    
    read_loop: LOOP
        FETCH center_cursor INTO v_center_id, v_partner_id, v_partner_name, v_partner_id_str;
        
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        -- Reset sequence for new partner
        IF @current_partner IS NULL OR @current_partner != v_partner_id THEN
            SET @current_partner = v_partner_id;
            SET @sequence = 0;
        END IF;
        
        -- Increment sequence
        SET @sequence = @sequence + 1;
        
        -- Get first 4 characters of partner name (uppercase, alphanumeric only)
        SET v_partner_prefix = UPPER(LEFT(REGEXP_REPLACE(v_partner_name, '[^A-Za-z0-9]', ''), 4));
        
        -- Pad with X if less than 4 characters
        WHILE LENGTH(v_partner_prefix) < 4 DO
            SET v_partner_prefix = CONCAT(v_partner_prefix, 'X');
        END WHILE;
        
        -- Generate center_id: PART0001-AMBU-0001
        SET v_new_center_id = CONCAT(
            REPLACE(v_partner_id_str, '-', ''),  -- PART0001
            '-',
            v_partner_prefix,  -- AMBU
            '-',
            LPAD(@sequence, 4, '0')  -- 0001
        );
        
        -- Update center with generated center_id
        UPDATE centers 
        SET center_id = v_new_center_id 
        WHERE id = v_center_id;
        
    END LOOP;
    
    CLOSE center_cursor;
END$$

DELIMITER ;

-- Execute the procedure
CALL generate_center_ids();

-- Drop the procedure
DROP PROCEDURE generate_center_ids;

-- Step 3: Make center_id NOT NULL after generating for all existing records
ALTER TABLE `centers` 
MODIFY COLUMN `center_id` VARCHAR(50) NOT NULL;

-- Step 4: Add trigger to auto-generate center_id on new center creation

DELIMITER $$

CREATE TRIGGER `before_center_insert` BEFORE INSERT ON `centers`
FOR EACH ROW
BEGIN
    DECLARE v_partner_name VARCHAR(255);
    DECLARE v_partner_id_str VARCHAR(20);
    DECLARE v_partner_prefix VARCHAR(4);
    DECLARE v_center_sequence INT;
    
    -- Only generate if center_id is not provided
    IF NEW.center_id IS NULL OR NEW.center_id = '' THEN
        -- Get partner details
        SELECT p.name, p.partner_id 
        INTO v_partner_name, v_partner_id_str
        FROM partners p 
        WHERE p.id = NEW.partner_id;
        
        -- Get next sequence number for this partner
        SELECT COALESCE(MAX(CAST(SUBSTRING_INDEX(center_id, '-', -1) AS UNSIGNED)), 0) + 1
        INTO v_center_sequence
        FROM centers
        WHERE partner_id = NEW.partner_id;
        
        -- Get first 4 characters of partner name (uppercase, alphanumeric only)
        SET v_partner_prefix = UPPER(LEFT(REGEXP_REPLACE(v_partner_name, '[^A-Za-z0-9]', ''), 4));
        
        -- Pad with X if less than 4 characters
        WHILE LENGTH(v_partner_prefix) < 4 DO
            SET v_partner_prefix = CONCAT(v_partner_prefix, 'X');
        END WHILE;
        
        -- Generate center_id: PART0001-AMBU-0001
        SET NEW.center_id = CONCAT(
            REPLACE(v_partner_id_str, '-', ''),  -- PART0001
            '-',
            v_partner_prefix,  -- AMBU
            '-',
            LPAD(v_center_sequence, 4, '0')  -- 0001
        );
    END IF;
END$$

DELIMITER ;

-- Verification queries (optional - comment out in production)
-- SELECT center_id, center_name, partner_id FROM centers ORDER BY partner_id, center_id;
-- SELECT p.partner_id, p.name, COUNT(c.id) as center_count FROM partners p LEFT JOIN centers c ON p.id = c.partner_id GROUP BY p.id;
