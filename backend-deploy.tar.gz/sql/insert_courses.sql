-- Insert courses into the courses table
-- Run this SQL to populate initial courses
-- MySQL version (using UUID() function)

INSERT INTO courses (id, course_name, course_code, description, duration_months, is_active, created_at, updated_at)
VALUES
  (
    UUID(),
    'Electrical',
    'ELEC-001',
    'Comprehensive training in electrical installations, wiring, circuit design, and maintenance. Covers residential and industrial electrical systems, safety protocols, and troubleshooting techniques.',
    6,
    1,
    NOW(),
    NOW()
  ),
  (
    UUID(),
    'Solar',
    'SOLR-001',
    'Specialized training in solar photovoltaic systems, panel installation, inverter configuration, and maintenance. Includes grid-tied and off-grid system design, energy efficiency, and renewable energy fundamentals.',
    6,
    1,
    NOW(),
    NOW()
  ),
  (
    UUID(),
    'Industrial Automation',
    'IAUT-001',
    'Advanced training in industrial automation systems, PLC programming, SCADA systems, and robotics. Covers sensor integration, control systems, industrial communication protocols, and automated manufacturing processes.',
    6,
    1,
    NOW(),
    NOW()
  );

-- Verify the insert
SELECT * FROM courses ORDER BY course_name;
