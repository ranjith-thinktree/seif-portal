-- Migration: Add readable partner_id column to partners table
-- Date: 2025-12-08
-- Description: Adds a human-readable partner_id column with auto-increment format (PART-0001, PART-0002, etc.)

-- Step 1: Add partner_id column (if it doesn't exist)
ALTER TABLE partners ADD COLUMN IF NOT EXISTS partner_id VARCHAR(20) UNIQUE AFTER id;

-- Step 2: Initialize row number variable
SET @row_number = 0;

-- Step 3: Generate partner_id for existing records based on created_at order
UPDATE partners 
SET partner_id = CONCAT('PART-', LPAD((@row_number:=@row_number + 1), 4, '0'))
WHERE partner_id IS NULL OR partner_id = ''
ORDER BY created_at;

-- Step 4: Drop existing trigger if it exists
DROP TRIGGER IF EXISTS before_partner_insert;

-- Step 5: Create trigger to auto-generate partner_id for new inserts
DELIMITER $$

CREATE TRIGGER before_partner_insert
BEFORE INSERT ON partners
FOR EACH ROW
BEGIN
    DECLARE next_num INT;
    
    IF NEW.partner_id IS NULL OR NEW.partner_id = '' THEN
        -- Get the next number by finding the max existing number
        SELECT COALESCE(MAX(CAST(SUBSTRING(partner_id, 6) AS UNSIGNED)), 0) + 1 
        INTO next_num
        FROM partners 
        WHERE partner_id LIKE 'PART-%';
        
        SET NEW.partner_id = CONCAT('PART-', LPAD(next_num, 4, '0'));
    END IF;
END$$

DELIMITER ;

-- Verification query (run this to check the migration)
SELECT id, partner_id, name, created_at FROM partners ORDER BY created_at LIMIT 10;
