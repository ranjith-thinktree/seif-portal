-- =====================================================
-- Create Reference Tables for Partner Onboarding
-- Date: December 9, 2025
-- =====================================================
-- This creates the missing reference tables:
-- countries, states, cities, regions, partner_state_presence
-- =====================================================

USE seif;

-- =====================================================
-- 1. CREATE REGIONS TABLE
-- =====================================================

CREATE TABLE IF NOT EXISTS `regions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(10) NOT NULL COMMENT 'N, S, E, W, UT',
  `name` VARCHAR(100) NOT NULL,
  `is_active` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP() ON UPDATE CURRENT_TIMESTAMP(),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 2. CREATE COUNTRIES TABLE
-- =====================================================

CREATE TABLE IF NOT EXISTS `countries` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `code` VARCHAR(10) NOT NULL COMMENT 'ISO country code',
  `iso3` VARCHAR(3) DEFAULT NULL COMMENT 'ISO 3166-1 alpha-3 code',
  `phone_code` VARCHAR(10) DEFAULT NULL COMMENT 'International dialing code',
  `currency` VARCHAR(10) DEFAULT NULL COMMENT 'Currency code',
  `is_active` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP() ON UPDATE CURRENT_TIMESTAMP(),
  UNIQUE KEY `code` (`code`),
  INDEX `idx_name` (`name`),
  INDEX `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 3. CREATE STATES TABLE
-- =====================================================

CREATE TABLE IF NOT EXISTS `states` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `country_id` INT NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `code` VARCHAR(10) DEFAULT NULL,
  `is_active` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP() ON UPDATE CURRENT_TIMESTAMP(),
  FOREIGN KEY (`country_id`) REFERENCES `countries`(`id`) ON DELETE CASCADE,
  INDEX `idx_country` (`country_id`),
  INDEX `idx_name` (`name`),
  INDEX `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 4. CREATE CITIES TABLE
-- =====================================================

CREATE TABLE IF NOT EXISTS `cities` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `state_id` INT DEFAULT NULL,
  `country_id` INT NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `latitude` VARCHAR(20) DEFAULT NULL COMMENT 'City latitude',
  `longitude` VARCHAR(20) DEFAULT NULL COMMENT 'City longitude',
  `is_active` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP() ON UPDATE CURRENT_TIMESTAMP(),
  FOREIGN KEY (`state_id`) REFERENCES `states`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`country_id`) REFERENCES `countries`(`id`) ON DELETE CASCADE,
  INDEX `idx_state` (`state_id`),
  INDEX `idx_country` (`country_id`),
  INDEX `idx_name` (`name`),
  INDEX `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 5. CREATE PARTNER STATE PRESENCE TABLE
-- =====================================================

CREATE TABLE IF NOT EXISTS `partner_state_presence` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `partner_id` char(36) NOT NULL,
  `state_id` INT NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
  UNIQUE KEY `partner_state` (`partner_id`, `state_id`),
  INDEX `idx_partner` (`partner_id`),
  INDEX `idx_state` (`state_id`),
  KEY `fk_partner` (`partner_id`),
  KEY `fk_state` (`state_id`),
  CONSTRAINT `partner_state_presence_ibfk_1` FOREIGN KEY (`partner_id`) REFERENCES `partners`(`id`) ON DELETE CASCADE,
  CONSTRAINT `partner_state_presence_ibfk_2` FOREIGN KEY (`state_id`) REFERENCES `states`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- =====================================================
-- 6. ADD REFERENCE COLUMNS TO PARTNERS TABLE (IF NOT EXISTS)
-- =====================================================

SET @dbname = DATABASE();
SET @tablename = 'partners';

-- Add country_ref_id
SET @column_check = (SELECT COUNT(*) 
                     FROM INFORMATION_SCHEMA.COLUMNS 
                     WHERE TABLE_SCHEMA = @dbname 
                     AND TABLE_NAME = @tablename 
                     AND COLUMN_NAME = 'country_ref_id');

SET @query = IF(@column_check = 0,
    'ALTER TABLE `partners` ADD COLUMN `country_ref_id` INT DEFAULT NULL COMMENT ''Reference to countries.id''',
    'SELECT ''Column country_ref_id already exists'' AS Info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add state_ref_id
SET @column_check = (SELECT COUNT(*) 
                     FROM INFORMATION_SCHEMA.COLUMNS 
                     WHERE TABLE_SCHEMA = @dbname 
                     AND TABLE_NAME = @tablename 
                     AND COLUMN_NAME = 'state_ref_id');

SET @query = IF(@column_check = 0,
    'ALTER TABLE `partners` ADD COLUMN `state_ref_id` INT DEFAULT NULL COMMENT ''Reference to states.id''',
    'SELECT ''Column state_ref_id already exists'' AS Info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add city_ref_id
SET @column_check = (SELECT COUNT(*) 
                     FROM INFORMATION_SCHEMA.COLUMNS 
                     WHERE TABLE_SCHEMA = @dbname 
                     AND TABLE_NAME = @tablename 
                     AND COLUMN_NAME = 'city_ref_id');

SET @query = IF(@column_check = 0,
    'ALTER TABLE `partners` ADD COLUMN `city_ref_id` INT DEFAULT NULL COMMENT ''Reference to cities.id''',
    'SELECT ''Column city_ref_id already exists'' AS Info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- =====================================================
-- 7. INSERT DEFAULT DATA
-- =====================================================

-- Insert Regions
INSERT IGNORE INTO `regions` (`code`, `name`, `is_active`) VALUES
('N', 'North', TRUE),
('S', 'South', TRUE),
('E', 'East', TRUE),
('W', 'West', TRUE),
('UT', 'Union Territory', TRUE);

-- Insert India as default country
INSERT IGNORE INTO `countries` (`name`, `code`, `is_active`) VALUES
('India', 'IN', TRUE);

-- Get India's ID
SET @india_id = (SELECT id FROM countries WHERE code = 'IN' LIMIT 1);

-- Insert Indian States and Union Territories
INSERT IGNORE INTO `states` (`country_id`, `name`, `code`, `is_active`) VALUES
(@india_id, 'Andhra Pradesh', 'AP', TRUE),
(@india_id, 'Arunachal Pradesh', 'AR', TRUE),
(@india_id, 'Assam', 'AS', TRUE),
(@india_id, 'Bihar', 'BR', TRUE),
(@india_id, 'Chhattisgarh', 'CG', TRUE),
(@india_id, 'Goa', 'GA', TRUE),
(@india_id, 'Gujarat', 'GJ', TRUE),
(@india_id, 'Haryana', 'HR', TRUE),
(@india_id, 'Himachal Pradesh', 'HP', TRUE),
(@india_id, 'Jharkhand', 'JH', TRUE),
(@india_id, 'Karnataka', 'KA', TRUE),
(@india_id, 'Kerala', 'KL', TRUE),
(@india_id, 'Madhya Pradesh', 'MP', TRUE),
(@india_id, 'Maharashtra', 'MH', TRUE),
(@india_id, 'Manipur', 'MN', TRUE),
(@india_id, 'Meghalaya', 'ML', TRUE),
(@india_id, 'Mizoram', 'MZ', TRUE),
(@india_id, 'Nagaland', 'NL', TRUE),
(@india_id, 'Odisha', 'OR', TRUE),
(@india_id, 'Punjab', 'PB', TRUE),
(@india_id, 'Rajasthan', 'RJ', TRUE),
(@india_id, 'Sikkim', 'SK', TRUE),
(@india_id, 'Tamil Nadu', 'TN', TRUE),
(@india_id, 'Telangana', 'TS', TRUE),
(@india_id, 'Tripura', 'TR', TRUE),
(@india_id, 'Uttar Pradesh', 'UP', TRUE),
(@india_id, 'Uttarakhand', 'UK', TRUE),
(@india_id, 'West Bengal', 'WB', TRUE),
(@india_id, 'Andaman and Nicobar Islands', 'AN', TRUE),
(@india_id, 'Chandigarh', 'CH', TRUE),
(@india_id, 'Dadra and Nagar Haveli and Daman and Diu', 'DH', TRUE),
(@india_id, 'Delhi', 'DL', TRUE),
(@india_id, 'Jammu and Kashmir', 'JK', TRUE),
(@india_id, 'Ladakh', 'LA', TRUE),
(@india_id, 'Lakshadweep', 'LD', TRUE),
(@india_id, 'Puducherry', 'PY', TRUE);

-- Insert major Indian cities for Maharashtra (as sample)
SET @maharashtra_id = (SELECT id FROM states WHERE code = 'MH' AND country_id = @india_id LIMIT 1);

INSERT IGNORE INTO `cities` (`state_id`, `country_id`, `name`, `is_active`) VALUES
(@maharashtra_id, @india_id, 'Mumbai', TRUE),
(@maharashtra_id, @india_id, 'Pune', TRUE),
(@maharashtra_id, @india_id, 'Nagpur', TRUE),
(@maharashtra_id, @india_id, 'Thane', TRUE),
(@maharashtra_id, @india_id, 'Nashik', TRUE),
(@maharashtra_id, @india_id, 'Aurangabad', TRUE);

-- =====================================================
-- 8. VERIFICATION
-- =====================================================

SELECT 'Tables created successfully!' AS Status;

SELECT 'Regions' as Table_Name, COUNT(*) as Count FROM regions
UNION ALL
SELECT 'Countries', COUNT(*) FROM countries
UNION ALL
SELECT 'States', COUNT(*) FROM states
UNION ALL
SELECT 'Cities', COUNT(*) FROM cities;

SELECT 'Sample Countries:' as Info;
SELECT id, name, code FROM countries LIMIT 5;

SELECT 'Sample States:' as Info;
SELECT id, name, code FROM states LIMIT 10;

SELECT 'Sample Cities:' as Info;
SELECT id, name, state_id, country_id FROM cities LIMIT 10;

-- =====================================================
-- END OF MIGRATION
-- =====================================================
