-- Performance Optimization Indexes
-- Run this SQL file to add indexes for faster queries on large datasets

-- ============================================
-- UPLOADED DATA TABLES INDEXES
-- ============================================

-- Index for filtering students by batch
ALTER TABLE uploaded_students 
  ADD INDEX IF NOT EXISTS idx_batch_id (batch_id);

-- Index for filtering batches by center
ALTER TABLE uploaded_batches 
  ADD INDEX IF NOT EXISTS idx_center_id (center_id);

-- Index for filtering centers by upload
ALTER TABLE uploaded_centers 
  ADD INDEX IF NOT EXISTS idx_upload_id (data_upload_id);

-- Composite index for filtering students by batch and status
ALTER TABLE uploaded_students 
  ADD INDEX IF NOT EXISTS idx_batch_status (batch_id, approval_status);

-- Index for filtering uploads by partner
ALTER TABLE data_uploads 
  ADD INDEX IF NOT EXISTS idx_partner_id (partner_id);

-- Index for filtering uploads by status
ALTER TABLE data_uploads 
  ADD INDEX IF NOT EXISTS idx_status (approval_status);

-- Index for sorting uploads by date
ALTER TABLE data_uploads 
  ADD INDEX IF NOT EXISTS idx_created_at (created_at DESC);

-- ============================================
-- PRODUCTION DATA TABLES INDEXES
-- ============================================

-- Index for filtering batches by center in production
ALTER TABLE batches 
  ADD INDEX IF NOT EXISTS idx_center_id (center_id);

-- Index for filtering centers by partner
ALTER TABLE centers 
  ADD INDEX IF NOT EXISTS idx_partner_id (partner_id);

-- Index for filtering centers by region
ALTER TABLE centers 
  ADD INDEX IF NOT EXISTS idx_region (region);

-- Index for filtering centers by type
ALTER TABLE centers 
  ADD INDEX IF NOT EXISTS idx_center_type (center_type);

-- ============================================
-- NOTIFICATIONS TABLE INDEXES
-- ============================================

-- Index for filtering notifications by user
ALTER TABLE notifications 
  ADD INDEX IF NOT EXISTS idx_user_id (user_id);

-- Index for filtering notifications by status
ALTER TABLE notifications 
  ADD INDEX IF NOT EXISTS idx_is_read (is_read);

-- Index for sorting notifications by date
ALTER TABLE notifications 
  ADD INDEX IF NOT EXISTS idx_created_at (created_at DESC);

-- Composite index for user notifications
ALTER TABLE notifications 
  ADD INDEX IF NOT EXISTS idx_user_read (user_id, is_read, created_at DESC);

-- ============================================
-- VERIFY INDEXES
-- ============================================

-- Run this to verify indexes were created:
-- SHOW INDEX FROM uploaded_students;
-- SHOW INDEX FROM uploaded_batches;
-- SHOW INDEX FROM uploaded_centers;
-- SHOW INDEX FROM data_uploads;
