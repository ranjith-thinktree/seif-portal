-- Migration: Add version tracking and edit logs
-- Date: 2025-11-26

-- Add version field to data_uploads table
ALTER TABLE `data_uploads`
ADD COLUMN `version` INT DEFAULT 1 COMMENT 'Version number for resubmitted data',
ADD COLUMN `parent_upload_id` CHAR(36) DEFAULT NULL COMMENT 'References original upload for version 2+',
ADD KEY `parent_upload_idx` (`parent_upload_id`),
ADD CONSTRAINT `data_uploads_parent_fk` FOREIGN KEY (`parent_upload_id`) REFERENCES `data_uploads` (`id`) ON DELETE SET NULL;

-- Create data_edit_logs table
CREATE TABLE `data_edit_logs` (
  `id` CHAR(36) NOT NULL,
  `upload_id` CHAR(36) NOT NULL COMMENT 'Reference to data_uploads',
  `version` INT NOT NULL COMMENT 'Version number when edit was made',
  `table_name` VARCHAR(100) NOT NULL COMMENT 'Table being edited: uploaded_students, uploaded_centers, uploaded_batches',
  `record_id` CHAR(36) NOT NULL COMMENT 'ID of the record being edited',
  `field_name` VARCHAR(100) NOT NULL COMMENT 'Name of the field/column being edited',
  `old_value` TEXT DEFAULT NULL COMMENT 'Original value before edit',
  `new_value` TEXT DEFAULT NULL COMMENT 'New value after edit',
  `edited_by` CHAR(36) NOT NULL COMMENT 'User ID who made the edit',
  `edit_type` VARCHAR(20) NOT NULL COMMENT 'Type of edit: update, insert, delete',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `data_edit_logs_upload_idx` (`upload_id`),
  KEY `data_edit_logs_record_idx` (`record_id`),
  KEY `data_edit_logs_edited_by_idx` (`edited_by`),
  KEY `data_edit_logs_table_idx` (`table_name`),
  CONSTRAINT `data_edit_logs_upload_fk` FOREIGN KEY (`upload_id`) REFERENCES `data_uploads` (`id`) ON DELETE CASCADE,
  CONSTRAINT `data_edit_logs_user_fk` FOREIGN KEY (`edited_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='Tracks all edits made to uploaded data before resubmission';

-- Create index for faster queries
CREATE INDEX `data_edit_logs_version_idx` ON `data_edit_logs` (`version`);
CREATE INDEX `data_edit_logs_created_at_idx` ON `data_edit_logs` (`created_at`);
