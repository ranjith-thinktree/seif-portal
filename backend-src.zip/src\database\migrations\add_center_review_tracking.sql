-- =====================================================
-- Center-Wise Review System Migration
-- =====================================================
-- NOTE: uploaded_centers, uploaded_batches, uploaded_students 
-- already have review_status, reviewed_by, reviewed_at columns.
-- This migration only adds the missing progress tracking columns
-- to the data_uploads table.
-- =====================================================

-- Add overall review progress tracking to data_uploads table
ALTER TABLE data_uploads
ADD COLUMN centers_total INT DEFAULT 0 COMMENT 'Total centers in this upload' AFTER total_records,
ADD COLUMN centers_reviewed INT DEFAULT 0 COMMENT 'Number of centers reviewed (approved or rejected)' AFTER centers_total,
ADD COLUMN centers_approved INT DEFAULT 0 COMMENT 'Number of centers approved' AFTER centers_reviewed,
ADD COLUMN centers_rejected INT DEFAULT 0 COMMENT 'Number of centers rejected' AFTER centers_approved,
ADD COLUMN review_progress ENUM('not_started', 'in_progress', 'completed') DEFAULT 'not_started' COMMENT 'Overall review progress status' AFTER centers_rejected;

-- Add total_centers and total_students for better tracking
ALTER TABLE data_uploads
ADD COLUMN total_centers INT DEFAULT 0 COMMENT 'Total centers in upload' AFTER total_records,
ADD COLUMN total_batches INT DEFAULT 0 COMMENT 'Total batches in upload' AFTER total_centers,
ADD COLUMN total_students INT DEFAULT 0 COMMENT 'Total students in upload' AFTER total_batches;
