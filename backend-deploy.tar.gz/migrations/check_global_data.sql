-- Check if global data was migrated
USE seif;

SELECT 'Countries' as Data_Type, COUNT(*) as Count FROM countries
UNION ALL
SELECT 'States', COUNT(*) FROM states
UNION ALL
SELECT 'Cities', COUNT(*) FROM cities
UNION ALL
SELECT 'Regions', COUNT(*) FROM regions;

-- Show sample countries
SELECT 'Sample Countries:' as Info;
SELECT id, name, code FROM countries LIMIT 10;

-- Show sample states
SELECT 'Sample States:' as Info;
SELECT id, name, code, country_id FROM states LIMIT 10;

-- Show sample cities
SELECT 'Sample Cities:' as Info;
SELECT id, name, state_id, country_id FROM cities LIMIT 10;

-- Check if new columns exist
SELECT 'Checking new columns:' as Info;
SHOW COLUMNS FROM countries LIKE 'iso3';
SHOW COLUMNS FROM countries LIKE 'phone_code';
SHOW COLUMNS FROM cities LIKE 'latitude';
