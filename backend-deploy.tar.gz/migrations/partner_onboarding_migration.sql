-- =====================================================
-- Partner Onboarding System - Complete Migration
-- =====================================================
-- This migration adds:
-- 1. New partner fields for comprehensive onboarding
-- 2. Reference tables (countries, states, cities, regions)
-- 3. Junction table for partner state presence
-- =====================================================

-- Add new columns to partners table
ALTER TABLE `partners`
ADD COLUMN `region` VARCHAR(50) DEFAULT NULL COMMENT 'N, S, E, W, UT (Union Territory)',
ADD COLUMN `contact_person_2_name` VARCHAR(255) DEFAULT NULL,
ADD COLUMN `contact_person_2_mobile` VARCHAR(20) DEFAULT NULL,
ADD COLUMN `date_of_incorporation` DATE DEFAULT NULL,
ADD COLUMN `legal_status` TEXT DEFAULT NULL COMMENT 'ACT under which it is registered',
ADD COLUMN `registered_as` VARCHAR(100) DEFAULT NULL COMMENT 'Trust, Foundation, Section 25 Company',
ADD COLUMN `fcra_registration_number` VARCHAR(100) DEFAULT NULL,
ADD COLUMN `years_of_experience` INT DEFAULT NULL COMMENT 'Years of experience in skill building';

-- =====================================================
-- Reference Tables
-- =====================================================

-- Countries Table
CREATE TABLE IF NOT EXISTS `countries` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `code` VARCHAR(10) NOT NULL COMMENT 'ISO country code',
  `is_active` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP() ON UPDATE CURRENT_TIMESTAMP(),
  UNIQUE KEY `code` (`code`),
  INDEX `idx_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- States/Provinces Table (country-specific)
CREATE TABLE IF NOT EXISTS `states` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `country_id` INT NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `code` VARCHAR(10) DEFAULT NULL,
  `is_active` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP() ON UPDATE CURRENT_TIMESTAMP(),
  FOREIGN KEY (`country_id`) REFERENCES `countries`(`id`) ON DELETE CASCADE,
  INDEX `idx_country` (`country_id`),
  INDEX `idx_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Cities Table (state and country specific)
CREATE TABLE IF NOT EXISTS `cities` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `state_id` INT DEFAULT NULL,
  `country_id` INT NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `is_active` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP() ON UPDATE CURRENT_TIMESTAMP(),
  FOREIGN KEY (`state_id`) REFERENCES `states`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`country_id`) REFERENCES `countries`(`id`) ON DELETE CASCADE,
  INDEX `idx_state` (`state_id`),
  INDEX `idx_country` (`country_id`),
  INDEX `idx_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Regions Table (simple dropdown values)
CREATE TABLE IF NOT EXISTS `regions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(10) NOT NULL COMMENT 'N, S, E, W, UT',
  `name` VARCHAR(100) NOT NULL,
  `is_active` BOOLEAN DEFAULT TRUE,
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Junction Table for Partner State Presence
-- =====================================================

CREATE TABLE IF NOT EXISTS `partner_state_presence` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `partner_id` CHAR(36) NOT NULL,
  `state_id` INT NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
  FOREIGN KEY (`partner_id`) REFERENCES `partners`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`state_id`) REFERENCES `states`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `partner_state` (`partner_id`, `state_id`),
  INDEX `idx_partner` (`partner_id`),
  INDEX `idx_state` (`state_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Insert Default Data
-- =====================================================

-- Insert Regions
INSERT INTO `regions` (`code`, `name`, `is_active`) VALUES
('N', 'North', TRUE),
('S', 'South', TRUE),
('E', 'East', TRUE),
('W', 'West', TRUE),
('UT', 'Union Territory', TRUE);

-- Insert India as default country
INSERT INTO `countries` (`name`, `code`, `is_active`) VALUES
('India', 'IN', TRUE);

-- Get India's ID for states insertion
SET @india_id = LAST_INSERT_ID();

-- Insert Indian States and Union Territories
INSERT INTO `states` (`country_id`, `name`, `code`, `is_active`) VALUES
(@india_id, 'Andhra Pradesh', 'AP', TRUE),
(@india_id, 'Arunachal Pradesh', 'AR', TRUE),
(@india_id, 'Assam', 'AS', TRUE),
(@india_id, 'Bihar', 'BR', TRUE),
(@india_id, 'Chhattisgarh', 'CG', TRUE),
(@india_id, 'Goa', 'GA', TRUE),
(@india_id, 'Gujarat', 'GJ', TRUE),
(@india_id, 'Haryana', 'HR', TRUE),
(@india_id, 'Himachal Pradesh', 'HP', TRUE),
(@india_id, 'Jharkhand', 'JH', TRUE),
(@india_id, 'Karnataka', 'KA', TRUE),
(@india_id, 'Kerala', 'KL', TRUE),
(@india_id, 'Madhya Pradesh', 'MP', TRUE),
(@india_id, 'Maharashtra', 'MH', TRUE),
(@india_id, 'Manipur', 'MN', TRUE),
(@india_id, 'Meghalaya', 'ML', TRUE),
(@india_id, 'Mizoram', 'MZ', TRUE),
(@india_id, 'Nagaland', 'NL', TRUE),
(@india_id, 'Odisha', 'OR', TRUE),
(@india_id, 'Punjab', 'PB', TRUE),
(@india_id, 'Rajasthan', 'RJ', TRUE),
(@india_id, 'Sikkim', 'SK', TRUE),
(@india_id, 'Tamil Nadu', 'TN', TRUE),
(@india_id, 'Telangana', 'TS', TRUE),
(@india_id, 'Tripura', 'TR', TRUE),
(@india_id, 'Uttar Pradesh', 'UP', TRUE),
(@india_id, 'Uttarakhand', 'UK', TRUE),
(@india_id, 'West Bengal', 'WB', TRUE),
(@india_id, 'Andaman and Nicobar Islands', 'AN', TRUE),
(@india_id, 'Chandigarh', 'CH', TRUE),
(@india_id, 'Dadra and Nagar Haveli and Daman and Diu', 'DH', TRUE),
(@india_id, 'Delhi', 'DL', TRUE),
(@india_id, 'Jammu and Kashmir', 'JK', TRUE),
(@india_id, 'Ladakh', 'LA', TRUE),
(@india_id, 'Lakshadweep', 'LD', TRUE),
(@india_id, 'Puducherry', 'PY', TRUE);

-- Insert major Indian cities for Maharashtra (as sample)
SET @maharashtra_id = (SELECT id FROM states WHERE code = 'MH' AND country_id = @india_id LIMIT 1);

INSERT INTO `cities` (`state_id`, `country_id`, `name`, `is_active`) VALUES
(@maharashtra_id, @india_id, 'Mumbai', TRUE),
(@maharashtra_id, @india_id, 'Pune', TRUE),
(@maharashtra_id, @india_id, 'Nagpur', TRUE),
(@maharashtra_id, @india_id, 'Thane', TRUE),
(@maharashtra_id, @india_id, 'Nashik', TRUE),
(@maharashtra_id, @india_id, 'Aurangabad', TRUE);

-- =====================================================
-- Update existing partners table constraints
-- =====================================================

-- Change partners.city and partners.state to reference the new tables (optional - for data integrity)
-- Note: Keeping them as VARCHAR for backward compatibility
-- If you want strict referential integrity, you would need to:
-- 1. Migrate existing data
-- 2. Change column types to INT
-- 3. Add foreign key constraints

-- =====================================================
-- Email notification system setup
-- =====================================================

-- Create table to track password reset tokens
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` CHAR(36) NOT NULL,
  `token` VARCHAR(255) NOT NULL,
  `expires_at` TIMESTAMP NOT NULL,
  `used` BOOLEAN DEFAULT FALSE,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_token` (`token`),
  INDEX `idx_user` (`user_id`),
  INDEX `idx_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- END OF MIGRATION
-- =====================================================
