-- Migration: Add is_edited flag to uploaded_students table
-- Date: 2025-12-02
-- Description: Add flag to track if student data has been edited by partner

ALTER TABLE `uploaded_students` 
ADD COLUMN `is_edited` TINYINT(1) DEFAULT 0 COMMENT 'Flag indicating if partner edited this record' 
AFTER `updated_at`;

-- Add index for faster querying of edited records
CREATE INDEX `idx_is_edited` ON `uploaded_students` (`is_edited`);

-- Add index for data_upload_id + is_edited for efficient querying
CREATE INDEX `idx_upload_edited` ON `uploaded_students` (`data_upload_id`, `is_edited`);
